# Builds the themed deck (index.html) from the classic deck in src/.
# Theme groups are self-contained and removable:
#   GROUP A  glass    : <style id="themes-glass">,   <script id="fx-glass">,   <span class="sgrp" data-group="glass">
#   GROUP B  motion   : <style id="themes-motion">,  <script id="fx-motion">,  <span class="sgrp" data-group="motion">
#   GROUP C  palette  : <style id="themes-palette">, <script id="fx-palette">, <span class="sgrp" data-group="palette">
import re
import sys,os
HERE=os.path.dirname(os.path.abspath(__file__))
src=sys.argv[1] if len(sys.argv)>1 else os.path.join(HERE,'..','src','altimetry-deck-classic.html')
dst=sys.argv[2] if len(sys.argv)>2 else os.path.join(HERE,'..','index.html')
s=open(src).read()
def rep(a,b):
    global s
    assert s.count(a)==1,(s.count(a),a[:80]); s=s.replace(a,b)
s=s.replace("'altimetry-deck:v2'","'altimetry-deck:themes'")
# ---- core hooks: theme list read from the buttons; group recorded on <html> ----
rep("const SKINS=['glacier','snow','seaice','ocean','aurora','dawn','firn'];","const SKINS=[...document.querySelectorAll('#skinSeg [data-skin]')].map(b=>b.dataset.skin);")
rep("function setSkin(k,quiet){if(!SKINS.includes(k))k='glacier';if(k==='glacier')delete document.documentElement.dataset.skin;else document.documentElement.dataset.skin=k;",
    "function setSkin(k,quiet){if(!SKINS.includes(k))k='glacier';const gb=$('#skinSeg [data-skin=\"'+k+'\"]'),gp=gb&&gb.closest('.sgrp');if(gp&&gp.dataset.group)document.documentElement.dataset.group=gp.dataset.group;else delete document.documentElement.dataset.group;if(k==='glacier')delete document.documentElement.dataset.skin;else document.documentElement.dataset.skin=k;")
rep("setSkin(store.skin||'glacier',true);","setSkin(store.skin||'silk',true);")
CORE_CSS='''
/* theme picker groups (preview) */
.skins{flex-wrap:wrap;max-width:340px;row-gap:6px}
.sgrp{display:flex;align-items:center;gap:inherit;flex-wrap:wrap}
.sgrp::before{content:attr(data-label);font:600 9px/1 var(--mono);letter-spacing:.12em;text-transform:uppercase;color:var(--muted);margin-right:2px}
.tb.dim .sgrp::before{display:none}
'''
rep('</style>',CORE_CSS+'</style>')
rep('<div class="spot" aria-hidden="true"></div>','<div class="spot" aria-hidden="true"></div>\n<!--FX-LAYERS-->')

# ================= GROUP A: GLASS =================
A_BTNS='''  <span class="sgrp" data-group="glass" data-label="Glass">
  <button data-skin="frost" title="Frosted glass" aria-label="Frosted glass theme" style="--s1:#dfe6ff;--s2:#d4f5ea"></button>
  <button data-skin="liquid" title="Liquid glass" aria-label="Liquid glass theme" style="--s1:#b3d2ff;--s2:#e6c6ff"></button>
  <button data-skin="borealis" title="Borealis" aria-label="Borealis theme" style="--s1:#9df0c9;--s2:#c4b0ff"></button>
  <button data-skin="biolum" title="Bioluminescent sea" aria-label="Bioluminescent sea theme" style="--s1:#9fe9f2;--s2:#a9cbff"></button>
  <button data-skin="crystal" title="Ice crystal" aria-label="Ice crystal theme" style="--s1:#ffffff;--s2:#cfe6ff"></button>
  <button data-skin="prism" title="Prism" aria-label="Prism theme" style="--s1:#ffc4e6;--s2:#bdeeff"></button>
  <button data-skin="sunset" title="Midnight-sun glass" aria-label="Midnight-sun glass theme" style="--s1:#ffcdb0;--s2:#cfd4ff"></button>
  </span>
'''
A_LAYERS='<div class="fxblobs" aria-hidden="true"><i></i><i></i><i></i><i></i></div><div class="fxaurora" aria-hidden="true"><i></i><i></i><i></i></div><div class="fxsheen" aria-hidden="true"></div><canvas id="fxCanvas" aria-hidden="true"></canvas>'
old=open(os.path.join(HERE,'glass_themes_src.py')).read()
A_CSS=old.split("CSS=r'''",1)[1].split("'''",1)[0]
A_CSS=A_CSS.replace('.skins{flex-wrap:wrap;max-width:300px}\n','').split('.preview-tag{')[0]
A_JS=old.split("JS=r'''",1)[1].split("'''",1)[0]

# ================= GROUP B: MOTION =================
B_BTNS='''  <span class="sgrp" data-group="motion" data-label="Motion">
  <button data-skin="silk" title="Champagne silk" aria-label="Champagne silk theme" style="--s1:#f6e3d3;--s2:#e8dcf3"></button>
  <button data-skin="lava" title="Lava glass" aria-label="Lava glass theme" style="--s1:#b8b0ff;--s2:#9fd4ff"></button>
  <button data-skin="contour" title="Cartographer" aria-label="Cartographer theme" style="--s1:#f6f1e3;--s2:#c9d3e6"></button>
  <button data-skin="orbital" title="Constellation" aria-label="Constellation theme" style="--s1:#e6e8fb;--s2:#f3dca6"></button>
  <button data-skin="caustic" title="Under-ice light" aria-label="Under-ice light theme" style="--s1:#cdf1f3;--s2:#ffffff"></button>
  <button data-skin="sonar" title="Sonar field" aria-label="Sonar field theme" style="--s1:#e3efeb;--s2:#9fc5bd"></button>
  </span>
'''
B_CSS='''
/* ===== THEME GROUP B · MOTION (remove this <style>, #fx-motion script and the "motion" button group to drop it) ===== */
:root[data-skin="silk"]{--g1:#f6e4d6;--g2:#ece2f3;--g3:#e2ebf6;--b1:#fcf9f6;--b2:#f3eee9;--glass:rgba(255,255,255,.5);--spot:198,140,110;--bg:#f5f0eb}
:root[data-skin="lava"]{--g1:#dcd6ff;--g2:#d3ecff;--g3:#ecdcff;--b1:#f4f4ff;--b2:#e9ebfa;--glass:rgba(255,255,255,.42);--spot:110,90,255;--bg:#eeeefc}
:root[data-skin="contour"]{--g1:#f2ecdc;--g2:#e6ebe2;--g3:#ece6d8;--b1:#fbf8f0;--b2:#f2eee3;--glass:rgba(255,253,247,.66);--spot:40,60,100;--bg:#f6f2e8}
:root[data-skin="orbital"]{--g1:#dfe2fb;--g2:#f4ead2;--g3:#e3e8f8;--b1:#f6f7fd;--b2:#eaecf7;--glass:rgba(255,255,255,.5);--spot:200,150,40;--bg:#eef0fa}
:root[data-skin="caustic"]{--g1:#c3eef2;--g2:#d4f3ee;--g3:#d8ebfa;--b1:#effafb;--b2:#ddf0f3;--glass:rgba(255,255,255,.46);--spot:0,160,190;--bg:#e4f4f6}
:root[data-skin="sonar"]{--g1:#dbece6;--g2:#e3ece9;--g3:#d6e6ea;--b1:#f5f9f7;--b2:#e8f0ed;--glass:rgba(255,255,255,.52);--spot:30,120,110;--bg:#eef4f2}
#fxMotion{position:fixed;inset:0;width:100vw;height:100vh;z-index:0;pointer-events:none;display:none}
:root[data-group="motion"] #fxMotion{display:block}
:root[data-group="motion"] .bgfx::after{opacity:0}
:root[data-group="motion"] .glass{-webkit-backdrop-filter:blur(22px) saturate(160%);backdrop-filter:blur(22px) saturate(160%);border:1px solid rgba(255,255,255,.72);
 box-shadow:inset 0 1px 0 rgba(255,255,255,.95),0 26px 60px -30px rgba(40,50,90,.32),0 2px 10px rgba(40,50,90,.05)}
:root[data-skin="contour"] .glass{border-color:rgba(255,255,255,.9);box-shadow:inset 0 1px 0 #fff,0 18px 40px -26px rgba(60,50,30,.35)}
'''
B_JS=r'''
/* ===== THEME GROUP B · MOTION: one canvas, a different generative scene per theme ===== */
(function(){const cv=document.getElementById('fxMotion');if(!cv)return;const c=cv.getContext('2d');let W=0,H=0,d=1,k=null,st={},t0=performance.now();
 const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
 const size=()=>{d=Math.min(2,devicePixelRatio||1);W=cv.width=innerWidth*d;H=cv.height=innerHeight*d;st={};};
 const R=(a,b)=>a+Math.random()*(b-a);
 const off=(w,h)=>{const o=document.createElement('canvas');o.width=w;o.height=h;return o;};
 const S={
  /* layered silk ribbons made of hundreds of fine threads */
  silk(t){const cols=[[198,140,110],[160,124,200],[110,140,205]];c.lineWidth=1.15*d;
   for(let b=0;b<3;b++){const [r,g,bl]=cols[b];for(let i=0;i<46;i++){const f=i/46;c.strokeStyle=`rgba(${r},${g},${bl},${(.07+.22*Math.sin(f*Math.PI)).toFixed(3)})`;c.beginPath();
     for(let x=-20;x<=W+20;x+=14*d){const u=x/W;const y=H*(.30+.2*b)+Math.sin(u*5.2+t*.22+b*1.9+f*.9)*H*.07+Math.sin(u*2.1-t*.13+b+f*2.2)*H*.09+f*H*.2*(1+.45*Math.sin(t*.3+u*3+b));x<0?c.moveTo(x,y):c.lineTo(x,y);}c.stroke();}}},
  /* metaball "lava" blobs rendered as glass: a field computed at low resolution, coloured and lit */
  lava(t){if(!st.o){st.w=Math.round(W/(8*d))||160;st.h=Math.round(H/(8*d))||90;st.o=off(st.w,st.h);st.oc=st.o.getContext('2d');st.img=st.oc.createImageData(st.w,st.h);
    st.b=Array.from({length:8},(_,i)=>({x:R(.1,.9),y:R(.1,.9),r:R(.07,.15),sx:R(.05,.12),sy:R(.05,.12),p:R(0,6)}));}
   const {w,h,img}=st,D=img.data,bs=st.b.map(b=>({x:(b.x+Math.sin(t*b.sx+b.p)*.18)*w,y:(b.y+Math.cos(t*b.sy*1.3+b.p)*.18)*h,r2:(b.r*w)**2}));
   for(let y=0;y<h;y++)for(let x=0;x<w;x++){let f=0;for(const b of bs){const dx=x-b.x,dy=y-b.y;f+=b.r2/(dx*dx+dy*dy+1);}
    const i=(y*w+x)*4;if(f<.6){D[i+3]=0;continue;}const e=Math.min(1,(f-.6)/.5),core=Math.min(1,(f-1)/3);const u=x/w;
    const rim=f<1.15?Math.min(1,(f-.6)/.25):Math.max(0,1-(f-1.15)/.6);D[i]=95+70*u+140*rim*.6;D[i+1]=85+80*(1-u)+150*rim*.6;D[i+2]=245+10*rim;D[i+3]=Math.round(255*Math.min(.62,(.22+.3*e+.25*rim)*(f<.75?(f-.6)/.15:1)));}
   st.oc.putImageData(img,0,0);c.save();c.imageSmoothingEnabled=true;c.filter='blur('+(2.5*d)+'px)';c.drawImage(st.o,0,0,W,H);c.restore();},
  /* animated topographic contour map (marching squares on a moving terrain) */
  contour(t){const cs=22*d,nx=Math.ceil(W/cs)+1,ny=Math.ceil(H/cs)+1;const F=new Float32Array(nx*ny);
   for(let j=0;j<ny;j++)for(let i=0;i<nx;i++){const x=i/nx*6,y=j/ny*3.4;F[j*nx+i]=Math.sin(x*.9+t*.07)+Math.cos(y*1.3-t*.05)+.6*Math.sin((x+y)*1.7+t*.11)+.35*Math.cos(x*2.6-y*2.1-t*.09)+.8*Math.exp(-((x-3-Math.sin(t*.05))**2+(y-1.7)**2)/1.2);}
   const L=[];for(let v=-2.6;v<=3.2;v+=.22)L.push(v);
   L.forEach((lv,li)=>{const major=li%5===0;c.strokeStyle=major?'rgba(40,58,100,.30)':'rgba(40,58,100,.13)';c.lineWidth=(major?1.3:.8)*d;c.beginPath();
    for(let j=0;j<ny-1;j++)for(let i=0;i<nx-1;i++){const a=F[j*nx+i],b=F[j*nx+i+1],e=F[(j+1)*nx+i+1],g=F[(j+1)*nx+i];let q=(a>lv)|((b>lv)<<1)|((e>lv)<<2)|((g>lv)<<3);if(q===0||q===15)continue;
     const x0=i*cs,y0=j*cs,P=[];const lp=(p,q2)=>(lv-p)/(q2-p);
     if((a>lv)!==(b>lv))P.push([x0+cs*lp(a,b),y0]);if((b>lv)!==(e>lv))P.push([x0+cs,y0+cs*lp(b,e)]);if((g>lv)!==(e>lv))P.push([x0+cs*lp(g,e),y0+cs]);if((a>lv)!==(g>lv))P.push([x0,y0+cs*lp(a,g)]);
     if(P.length>=2){c.moveTo(P[0][0],P[0][1]);c.lineTo(P[1][0],P[1][1]);}if(P.length===4){c.moveTo(P[2][0],P[2][1]);c.lineTo(P[3][0],P[3][1]);}}c.stroke();});},
  /* tilted orbits with small glowing satellites and fading trails */
  orbital(t){if(!st.o){st.o=[0,1,2,3,4].map(i=>({rx:R(.28,.5),ry:R(.07,.16),rot:R(-.5,.5),sp:R(.08,.2)*(i%2?1:-1),n:2+(i%2),col:i%2?'60,170,220':'205,150,40',ph:R(0,6)}));}
   const cx=W*.62,cy=H*.52;st.o.forEach(o=>{c.save();c.translate(cx,cy);c.rotate(o.rot);c.strokeStyle='rgba(70,80,140,.2)';c.lineWidth=1.1*d;c.beginPath();c.ellipse(0,0,o.rx*W,o.ry*W,0,0,7);c.stroke();
    for(let s=0;s<o.n;s++){const a0=t*o.sp+o.ph+s*6.283/o.n;for(let k2=40;k2>=0;k2--){const a=a0-k2*.012*Math.sign(o.sp);const x=Math.cos(a)*o.rx*W,y=Math.sin(a)*o.ry*W;
      c.fillStyle=`rgba(${o.col},${((1-k2/40)*.6).toFixed(3)})`;c.beginPath();c.arc(x,y,(k2?1.6:3.2)*d,0,7);c.fill();}
     const x=Math.cos(a0)*o.rx*W,y=Math.sin(a0)*o.ry*W;c.shadowBlur=14*d;c.shadowColor=`rgba(${o.col},.9)`;c.fillStyle=`rgba(${o.col},.95)`;c.beginPath();c.arc(x,y,3.4*d,0,7);c.fill();c.shadowBlur=0;}c.restore();});
   const g=c.createRadialGradient(cx,cy,0,cx,cy,W*.09);g.addColorStop(0,'rgba(120,140,230,.22)');g.addColorStop(1,'rgba(120,140,230,0)');c.fillStyle=g;c.beginPath();c.arc(cx,cy,W*.09,0,7);c.fill();},
  /* sunlight caustics seen from under sea ice */
  caustic(t){if(!st.o){st.w=Math.round(W/(6*d))||200;st.h=Math.round(H/(6*d))||110;st.o=off(st.w,st.h);st.oc=st.o.getContext('2d');st.img=st.oc.createImageData(st.w,st.h);}
   const {w,h,img}=st,D=img.data;for(let y=0;y<h;y++)for(let x=0;x<w;x++){const u=x/w*9,v=y/h*5.2;
    let p=Math.sin(u+Math.sin(v*1.3+t*.6)*1.4+t*.4)+Math.sin(v*1.7+Math.sin(u*.9-t*.5)*1.6-t*.3)+Math.sin((u+v)*.8+t*.25);
    const k2=Math.pow(Math.max(0,1-Math.abs(p)/1.2),5);const i=(y*w+x)*4;D[i]=20;D[i+1]=150;D[i+2]=180;D[i+3]=Math.round(255*k2*.42*(.55+.45*(1-y/h)));}
   st.oc.putImageData(img,0,0);c.save();c.imageSmoothingEnabled=true;c.filter='blur('+(2*d)+'px)';c.drawImage(st.o,0,0,W,H);c.restore();
   const g=c.createLinearGradient(0,0,0,H);g.addColorStop(0,'rgba(255,255,255,.35)');g.addColorStop(1,'rgba(0,120,150,.06)');c.fillStyle=g;c.fillRect(0,0,W,H);},
  /* dot matrix rippling with interfering sonar pulses */
  sonar(t){const gap=26*d;const src=[[.2+.06*Math.sin(t*.2),.3],[.78,.65+.05*Math.cos(t*.17)],[.55+.1*Math.sin(t*.1),.15]];
   for(let y=gap/2;y<H;y+=gap)for(let x=gap/2;x<W;x+=gap){let v=0;for(const [sx,sy] of src){const r=Math.hypot(x-sx*W,y-sy*H)/d;v+=Math.sin(r*.035-t*1.6)*Math.exp(-r/900);}
    const a=(v+1.6)/3.2;c.fillStyle=v>0?`rgba(20,130,118,${(.08+.32*a).toFixed(3)})`:`rgba(40,60,90,${(.06+.14*a).toFixed(3)})`;c.beginPath();c.arc(x,y,(.8+2.2*Math.max(0,a))*d,0,7);c.fill();}}
 };
 size();addEventListener('resize',size);
 const pick=()=>{const g=document.documentElement.dataset.group,s=document.documentElement.dataset.skin;k=(g==='motion'&&S[s])?s:null;st={};if(!k)c.clearRect(0,0,W,H);};
 pick();new MutationObserver(pick).observe(document.documentElement,{attributes:true,attributeFilter:['data-skin','data-group']});
 let lastDraw=0;
 function frame(now){requestAnimationFrame(frame);if(!k||document.hidden)return;if(reduce&&lastDraw)return;if(now-lastDraw<(k==='lava'||k==='caustic'?33:16))return;lastDraw=now;
  c.clearRect(0,0,W,H);S[k]((now-t0)/1000);}
 requestAnimationFrame(frame);})();
'''

# ================= GROUP C: PALETTE =================
C_BTNS='''  <span class="sgrp" data-group="palette" data-label="Palette">
  <button data-skin="ember" title="Ember & basalt" aria-label="Ember and basalt palette" style="--s1:#c2410c;--s2:#0f766e"></button>
  <button data-skin="royal" title="Royal ink" aria-label="Royal ink palette" style="--s1:#4338ca;--s2:#c026d3"></button>
  <button data-skin="forest" title="Forest lab" aria-label="Forest lab palette" style="--s1:#15803d;--s2:#b45309"></button>
  <button data-skin="reef" title="Coral reef" aria-label="Coral reef palette" style="--s1:#0e7490;--s2:#db2777"></button>
  <button data-skin="graphite" title="Graphite & signal" aria-label="Graphite and signal palette" style="--s1:#334155;--s2:#e11d48"></button>
  <button data-skin="okabe" title="Okabe–Ito (colour-blind safe)" aria-label="Okabe-Ito colour-blind safe palette" style="--s1:#0072b2;--s2:#d55e00"></button>
  </span>
'''
C_CSS='''
/* ===== THEME GROUP C · PALETTE (remove this <style>, #fx-palette script and the "palette" button group to drop it) ===== */
:root[data-skin="ember"]{--g1:#f6e2d6;--g2:#dcebe7;--g3:#eee7df;--b1:#fbf8f5;--b2:#f1ece7;--glass:rgba(255,255,255,.62);--spot:194,65,12;--bg:#f3eee9}
:root[data-skin="royal"]{--g1:#dedcfb;--g2:#f3dcf6;--g3:#dbe9f7;--b1:#f8f7fe;--b2:#eeedf8;--glass:rgba(255,255,255,.62);--spot:67,56,202;--bg:#f0eff9}
:root[data-skin="forest"]{--g1:#dcefdd;--g2:#f3e6d3;--g3:#e2ecdc;--b1:#f8fbf6;--b2:#edf2ea;--glass:rgba(255,255,255,.62);--spot:21,128,61;--bg:#eef3eb}
:root[data-skin="reef"]{--g1:#cfedf2;--g2:#fbdce9;--g3:#fde5d4;--b1:#f6fbfc;--b2:#ebf3f5;--glass:rgba(255,255,255,.6);--spot:14,116,144;--bg:#eef5f6}
:root[data-skin="graphite"]{--g1:#e3e7ec;--g2:#f3e2e6;--g3:#e5eaf0;--b1:#f8f9fb;--b2:#eceff3;--glass:rgba(255,255,255,.66);--spot:51,65,85;--bg:#eff1f4}
:root[data-skin="okabe"]{--g1:#dbe9f5;--g2:#f6e7d8;--g3:#e1f0ea;--b1:#f8fafc;--b2:#edf1f5;--glass:rgba(255,255,255,.64);--spot:0,114,178;--bg:#eff2f6}
'''
C_JS=r'''
/* ===== THEME GROUP C · PALETTE: recolours every object (CSS, SVG and canvas) by colour family ===== */
(function(){
 const fam={radar:['#2a56c6','#2a4f9e','#3d7bd9','#dde6fb','#3a6cba','#4e7cc0','#5a96e1','#1f45a8'],ka:['#0f8790','#d7f0f1'],laser:['#0e9a55','#0a7a42','#0a8048','#d8f2e4'],
  ir:['#c2364a','#f7dde1'],amber:['#b7791f','#93600f','#8a6512','#e9b949','#e39a2a','#f8ecd5','#9a6512'],violet:['#7b5bb8','#6a4aa8','#6f42c1','#3b3fb5','#6b45ad']};
 const BASE={radar:'#2a56c6',ka:'#0f8790',laser:'#0e9a55',ir:'#c2364a',amber:'#b7791f',violet:'#6a4aa8'};
 const PAL={ember:{radar:'#c2410c',ka:'#a16207',laser:'#0f766e',ir:'#7c3aed',amber:'#be123c',violet:'#475569'},
  royal:{radar:'#4338ca',ka:'#0369a1',laser:'#c026d3',ir:'#dc2626',amber:'#ca8a04',violet:'#0d9488'},
  forest:{radar:'#15803d',ka:'#4d7c0f',laser:'#b45309',ir:'#9f1239',amber:'#1d4ed8',violet:'#7e22ce'},
  reef:{radar:'#0e7490',ka:'#2563eb',laser:'#db2777',ir:'#ea580c',amber:'#65a30d',violet:'#9333ea'},
  graphite:{radar:'#334155',ka:'#0891b2',laser:'#e11d48',ir:'#f59e0b',amber:'#16a34a',violet:'#6366f1'},
  okabe:{radar:'#0072b2',ka:'#3a9bd1',laser:'#009e73',ir:'#d55e00',amber:'#e69f00',violet:'#cc79a7'}};
 const hx=h=>[parseInt(h.slice(1,3),16),parseInt(h.slice(3,5),16),parseInt(h.slice(5,7),16)];
 const hsl=([r,g,b])=>{r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),l=(mx+mn)/2;let h=0,s=0;if(mx!==mn){const dd=mx-mn;s=l>.5?dd/(2-mx-mn):dd/(mx+mn);h=mx===r?(g-b)/dd+(g<b?6:0):mx===g?(b-r)/dd+2:(r-g)/dd+4;h/=6;}return [h,s,l];};
 const rgb=([h,s,l])=>{const f=n=>{const k=(n+h*12)%12,a=s*Math.min(l,1-l);return Math.round(255*(l-a*Math.max(-1,Math.min(k-3,9-k,1))));};return [f(0),f(8),f(4)];};
 const cl=v=>Math.max(0,Math.min(1,v));
 const KEY=new Map();Object.entries(fam).forEach(([f,list])=>list.forEach(h=>KEY.set(hx(h).join(','),f)));
 let P=null,cache=new Map();
 const mapRGB=(r,g,b)=>{const f=KEY.get(r+','+g+','+b);if(!f||!P)return null;const s0=hsl([r,g,b]),b0=hsl(hx(BASE[f])),t0=hsl(hx(P[f]));
  return rgb([((t0[0]+(s0[0]-b0[0]))%1+1)%1,cl(t0[1]*(b0[1]?s0[1]/b0[1]:1)),cl(t0[2]+(s0[2]-b0[2]))]);};
 const RE=/#([0-9a-fA-F]{6})\b|rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)/g;
 const mapStr=str=>{if(!P||typeof str!=='string')return str;let o=cache.get(str);if(o!==undefined)return o;
  o=str.replace(RE,(m,h,r,g,b,a)=>{const c0=h?hx('#'+h):[+r,+g,+b];const n=mapRGB(...c0);if(!n)return m;return a!=null?`rgba(${n[0]},${n[1]},${n[2]},${a})`:(h?'#'+n.map(v=>v.toString(16).padStart(2,'0')).join(''):`rgb(${n.join(',')})`);});
  cache.set(str,o);return o;};
 window.__palMap=mapStr;
 /* canvas: colours are mapped as they are set, so every animated figure follows the palette */
 const CP=CanvasRenderingContext2D.prototype;['fillStyle','strokeStyle','shadowColor'].forEach(p=>{const dsc=Object.getOwnPropertyDescriptor(CP,p);if(!dsc||!dsc.set)return;
  Object.defineProperty(CP,p,{get(){return dsc.get.call(this);},set(v){dsc.set.call(this,P&&typeof v==='string'?mapStr(v):v);},configurable:true});});
 const acs=CanvasGradient.prototype.addColorStop;CanvasGradient.prototype.addColorStop=function(o,col){return acs.call(this,o,P?mapStr(col):col);};
 /* SVG and HTML: attributes and inline styles, with the originals kept for restoring */
 const ATTR=['fill','stroke','stop-color','color','style'];const stage=document.getElementById('stage');let busy=false;
 const fixEl=el=>{if(el.nodeType!==1)return;const o=el.__oc||(el.__oc={}),m=el.__om||(el.__om={});for(const a of ATTR){const v=el.getAttribute(a);if(v==null)continue;
   if(!(a in o)||(v!==m[a]&&v!==o[a]))o[a]=v;const want=P?mapStr(o[a]):o[a];if(v!==want)el.setAttribute(a,want);m[a]=want;}};
 const sweep=root=>{busy=true;if(root.nodeType===1){fixEl(root);root.querySelectorAll('*').forEach(fixEl);}busy=false;};
 new MutationObserver(ms=>{if(busy||!P)return;busy=true;for(const m of ms){if(m.type==='attributes')fixEl(m.target);else m.addedNodes.forEach(n=>{if(n.nodeType===1){fixEl(n);n.querySelectorAll&&n.querySelectorAll('*').forEach(fixEl);}});}busy=false;})
  .observe(stage,{subtree:true,childList:true,attributes:true,attributeFilter:ATTR});
 /* stylesheet colours and the semantic CSS variables */
 const sheets=[...document.querySelectorAll('style')].filter(x=>!x.id||x.id.indexOf('themes-')!==0);sheets.forEach(x=>x.__orig=x.textContent);
 const VARS={radar:'--radar',ka:'--ka',laser:'--laser',ir:'--ir',amber:'--amber'};
 function apply(){const k=document.documentElement.dataset.skin,g=document.documentElement.dataset.group;const np=(g==='palette'&&PAL[k])?PAL[k]:null;if(np===P)return;P=np;cache=new Map();
  sheets.forEach(x=>{x.textContent=P?mapStr(x.__orig):x.__orig;});
  const rs=document.documentElement.style;Object.entries(VARS).forEach(([f,v])=>{if(P){rs.setProperty(v,P[f]);const t=hsl(hx(P[f]));rs.setProperty(v+'-soft','rgb('+rgb([t[0],cl(t[1]*.75),.92]).join(',')+')');}else{rs.removeProperty(v);rs.removeProperty(v+'-soft');}});
  sweep(stage);if(typeof window.__repaint==='function')window.__repaint();}
 apply();new MutationObserver(apply).observe(document.documentElement,{attributes:true,attributeFilter:['data-skin','data-group']});
})();
'''
# ---- assemble ----
a='  <button data-skin="firn" title="Firn" aria-label="Firn theme" style="--s1:#f4eee3;--s2:#d6e3ee"></button>\n'
rep(a,a+'  <!-- THEME GROUP A: GLASS -->\n'+A_BTNS+'  <!-- THEME GROUP B: MOTION -->\n'+B_BTNS+'  <!-- THEME GROUP C: PALETTE -->\n'+C_BTNS)
rep('<!--FX-LAYERS-->','<!-- THEME GROUP A: GLASS -->'+A_LAYERS+'\n<!-- THEME GROUP B: MOTION --><canvas id="fxMotion" aria-hidden="true"></canvas>')
rep('</head>','<!-- THEME GROUP A: GLASS --><style id="themes-glass">'+A_CSS+'</style>\n<!-- THEME GROUP B: MOTION --><style id="themes-motion">'+B_CSS+'</style>\n<!-- THEME GROUP C: PALETTE --><style id="themes-palette">'+C_CSS+'</style>\n</head>')
# palette engine must patch canvas before figures draw: place it first in <body>
rep('<div class="bgfx" aria-hidden="true"></div>','<!-- THEME GROUP C: PALETTE --><script id="fx-palette">document.addEventListener("DOMContentLoaded",function(){});</script>\n<div class="bgfx" aria-hidden="true"></div>')
s=s.replace('</body>','<!-- THEME GROUP A: GLASS --><script id="fx-glass">'+A_JS+'</script>\n<!-- THEME GROUP B: MOTION --><script id="fx-motion">'+B_JS+'</script>\n</body>',1)
# palette engine needs #stage and the setSkin result; run it right after the main script
s=s.replace('<script id="fx-palette">document.addEventListener("DOMContentLoaded",function(){});</script>\n','')
s=s.replace('<!-- THEME GROUP A: GLASS --><script id="fx-glass">','<!-- THEME GROUP C: PALETTE --><script id="fx-palette">'+C_JS+'</script>\n<!-- THEME GROUP A: GLASS --><script id="fx-glass">',1)

# ---- compact theme picker: one swatch in the toolbar, all groups in a dropdown ----
rep(' <div class="skins" id="skinSeg" role="group" aria-label="Theme">\n  <button data-skin="glacier"',
    ' <div class="skins" id="skinSeg" role="group" aria-label="Theme"><button class="skcur" type="button" title="Themes" aria-label="Choose theme" aria-expanded="false"></button><div class="skpanel">\n  <span class="sgrp" data-label="Classic">\n  <button data-skin="glacier"')
rep('  <!-- THEME GROUP A: GLASS -->\n  <span class="sgrp" data-group="glass"','  </span>\n  <!-- THEME GROUP A: GLASS -->\n  <span class="sgrp" data-group="glass"')
i=s.index('<span class="sgrp" data-group="palette"');j=s.index('</span>',i)+len('</span>');k=s.index('</div>',j)
s=s[:k]+'</div>'+s[k:]
PICK_CSS=""".skins{position:relative;flex-wrap:nowrap;max-width:none}
.skins .skcur{width:24px;height:24px;border-radius:50%;border:2px solid #fff;cursor:pointer;background:linear-gradient(135deg,var(--c1,#dfe9fb),var(--c2,#dcf1e7));box-shadow:0 0 0 1px rgba(19,32,58,.15),0 2px 6px rgba(28,48,90,.25)}
.skpanel{position:absolute;top:36px;left:-8px;z-index:50;display:none;flex-direction:column;gap:9px;padding:14px 16px;border-radius:16px;background:rgba(255,255,255,.95);
 -webkit-backdrop-filter:blur(18px);backdrop-filter:blur(18px);border:1px solid rgba(19,32,58,.08);box-shadow:0 24px 50px -22px rgba(28,48,90,.45);width:max-content}
.skins.open .skpanel{display:flex}
.skpanel .sgrp{display:grid;grid-template-columns:62px repeat(7,22px);align-items:center;gap:8px}
.skpanel .sgrp::before{grid-column:1;margin:0}
.tb.dim .skpanel{display:none!important}
.tb.dim .skins .skcur{display:inline-block}
"""
rep('.tb.dim .sgrp::before{display:none}','.tb.dim .sgrp::before{display:none}\n'+PICK_CSS)
PICK_JS="""
/* compact theme picker */
(function(){const box=document.getElementById('skinSeg'),cur=box&&box.querySelector('.skcur');if(!cur)return;
 const sync=()=>{const k=document.documentElement.dataset.skin||'glacier',b=box.querySelector('[data-skin="'+k+'"]');if(b){cur.style.setProperty('--c1',getComputedStyle(b).getPropertyValue('--s1'));cur.style.setProperty('--c2',getComputedStyle(b).getPropertyValue('--s2'));cur.title='Theme: '+b.title;}};
 cur.onclick=e=>{e.stopPropagation();const o=box.classList.toggle('open');cur.setAttribute('aria-expanded',o);};
 box.querySelectorAll('[data-skin]').forEach(b=>b.addEventListener('click',()=>setTimeout(sync,0)));
 document.addEventListener('pointerdown',e=>{if(!box.contains(e.target))box.classList.remove('open');});
 sync();new MutationObserver(sync).observe(document.documentElement,{attributes:true,attributeFilter:['data-skin']});})();
"""
s=s.replace('</body>','<script id="theme-picker">'+PICK_JS+'</script>\n</body>',1)

open(dst,'w').write(s)
print('ok',len(s))
