import re
src='/home/claude/altimetry-deck.html'; dst='/home/claude/preview/altimetry-themes-preview.html'
s=open(src).read()
def rep(a,b):
    global s
    assert s.count(a)==1,a[:80]; s=s.replace(a,b)
# separate storage so the preview never touches the real deck's saved settings or comments
s=s.replace("'altimetry-deck:v2'","'altimetry-deck:theme-preview'")
rep('<title>Radar vs Laser Altimetry</title>','<title>Theme preview · Radar vs Laser Altimetry</title>')
CSS=r'''
/* ===== preview themes: glass, liquid glass and animated backgrounds ===== */
:root[data-skin="frost"]{--g1:#c9d8ff;--g2:#c6f0e4;--g3:#ead2ff;--b1:#eef3ff;--b2:#e3ebf8;--glass:rgba(255,255,255,.42);--spot:90,120,255;--bg:#e6ecf8}
:root[data-skin="liquid"]{--g1:#9ec5ff;--g2:#9ff0d8;--g3:#e3b8ff;--b1:#eaf1ff;--b2:#dfe8fb;--glass:rgba(255,255,255,.26);--spot:120,90,255;--bg:#e2eafb}
:root[data-skin="borealis"]{--g1:#b8f0d6;--g2:#cdb9ff;--g3:#a8e6ff;--b1:#eef6f8;--b2:#e1ebf3;--glass:rgba(255,255,255,.46);--spot:14,170,110;--bg:#e6f0f3}
:root[data-skin="biolum"]{--g1:#a6e9f0;--g2:#b5d6ff;--g3:#c2f5e6;--b1:#eaf7fa;--b2:#d9ecf3;--glass:rgba(255,255,255,.44);--spot:0,170,200;--bg:#e0f0f4}
:root[data-skin="crystal"]{--g1:#d9ecff;--g2:#e6f7ff;--g3:#e9e4ff;--b1:#f7fbff;--b2:#eaf2fa;--glass:rgba(255,255,255,.40);--spot:90,160,230;--bg:#eef4fa}
:root[data-skin="prism"]{--g1:#ffd6ec;--g2:#c9f3ff;--g3:#fff0c4;--b1:#fbf8ff;--b2:#efeefa;--glass:rgba(255,255,255,.38);--spot:200,90,220;--bg:#f2f0fb}
:root[data-skin="sunset"]{--g1:#ffd2b8;--g2:#ffc6df;--g3:#c9d2ff;--b1:#fff6f1;--b2:#f6ebf1;--glass:rgba(255,255,255,.44);--spot:240,110,80;--bg:#f7eef0}

/* animated colour fields behind everything */
.fxblobs{position:fixed;inset:-10%;z-index:0;pointer-events:none;display:none;filter:blur(60px) saturate(1.15);opacity:.85}
.fxblobs i{position:absolute;width:46vmax;height:46vmax;border-radius:50%;mix-blend-mode:multiply;opacity:.55;animation:blob 26s ease-in-out infinite alternate}
.fxblobs i:nth-child(1){left:-6%;top:-8%;background:var(--g1);animation-duration:24s}
.fxblobs i:nth-child(2){right:-8%;top:10%;background:var(--g3);animation-duration:31s;animation-delay:-8s}
.fxblobs i:nth-child(3){left:20%;bottom:-18%;background:var(--g2);animation-duration:28s;animation-delay:-14s}
.fxblobs i:nth-child(4){right:18%;bottom:-6%;width:30vmax;height:30vmax;background:var(--g1);animation-duration:35s;animation-delay:-20s}
@keyframes blob{0%{transform:translate(0,0) scale(1) rotate(0)}33%{transform:translate(8vw,5vh) scale(1.15) rotate(40deg)}66%{transform:translate(-6vw,9vh) scale(.92) rotate(-30deg)}100%{transform:translate(4vw,-6vh) scale(1.08) rotate(20deg)}}
:root[data-skin="liquid"] .fxblobs,:root[data-skin="frost"] .fxblobs,:root[data-skin="prism"] .fxblobs,:root[data-skin="sunset"] .fxblobs{display:block}
:root[data-skin="liquid"] .fxblobs i{opacity:.9;border-radius:42% 58% 63% 37%/45% 38% 62% 55%}

/* aurora ribbons */
.fxaurora{position:fixed;left:-20%;right:-20%;top:-12%;height:66%;z-index:0;pointer-events:none;display:none;filter:blur(30px);opacity:.95}
.fxaurora i{position:absolute;left:0;right:0;height:42%;border-radius:50%;transform-origin:50% 50%;animation:ribbon 18s ease-in-out infinite alternate}
.fxaurora i:nth-child(1){top:8%;background:linear-gradient(90deg,transparent,rgba(40,210,140,.55),rgba(90,230,200,.45),rgba(150,110,255,.35),transparent)}
.fxaurora i:nth-child(2){top:28%;background:linear-gradient(90deg,transparent,rgba(150,110,255,.38),rgba(40,200,160,.5),transparent);animation-duration:24s;animation-delay:-9s}
.fxaurora i:nth-child(3){top:44%;background:linear-gradient(90deg,transparent,rgba(80,190,255,.32),rgba(60,220,150,.42),transparent);animation-duration:30s;animation-delay:-15s}
@keyframes ribbon{0%{transform:translateX(-6%) skewY(-4deg) scaleY(.8)}50%{transform:translateX(5%) skewY(3deg) scaleY(1.15)}100%{transform:translateX(-2%) skewY(-2deg) scaleY(.9)}}
:root[data-skin="borealis"] .fxaurora{display:block}

/* holographic sheen for prism */
.fxsheen{position:fixed;inset:0;z-index:0;pointer-events:none;display:none;opacity:.35;mix-blend-mode:soft-light;
 background:conic-gradient(from var(--ang,0deg) at 50% 50%,#ff7ad9,#7ad7ff,#9dffb0,#ffe57a,#ff7ad9);animation:spin 40s linear infinite}
@property --ang{syntax:'<angle>';inherits:false;initial-value:0deg}
@keyframes spin{to{--ang:360deg}}
:root[data-skin="prism"] .fxsheen{display:block}

/* glowing particles canvas */
#fxCanvas{position:fixed;inset:0;width:100vw;height:100vh;z-index:0;pointer-events:none;display:none}
:root[data-skin="frost"] #fxCanvas,:root[data-skin="liquid"] #fxCanvas,:root[data-skin="borealis"] #fxCanvas,:root[data-skin="biolum"] #fxCanvas,:root[data-skin="crystal"] #fxCanvas,:root[data-skin="prism"] #fxCanvas,:root[data-skin="sunset"] #fxCanvas{display:block}
:root[data-skin="frost"] .bgfx::after,:root[data-skin="liquid"] .bgfx::after,:root[data-skin="borealis"] .bgfx::after,:root[data-skin="biolum"] .bgfx::after,:root[data-skin="crystal"] .bgfx::after,:root[data-skin="prism"] .bgfx::after,:root[data-skin="sunset"] .bgfx::after{opacity:.35}

/* glass surfaces */
:root[data-skin="frost"] .glass,:root[data-skin="borealis"] .glass,:root[data-skin="biolum"] .glass,:root[data-skin="crystal"] .glass,:root[data-skin="sunset"] .glass{
 -webkit-backdrop-filter:blur(26px) saturate(170%);backdrop-filter:blur(26px) saturate(170%);border:1px solid rgba(255,255,255,.7);
 box-shadow:inset 0 1px 0 rgba(255,255,255,.95),inset 0 0 0 1px rgba(255,255,255,.18),0 26px 60px -30px rgba(40,60,120,.35),0 2px 10px rgba(40,60,120,.06)}
/* liquid glass: thin, very clear, with a moving specular edge and soft refraction */
:root[data-skin="liquid"] .glass,:root[data-skin="prism"] .glass{
 background:radial-gradient(520px circle at var(--mx,50%) var(--my,-60%),rgba(255,255,255,calc(var(--gl,0) + .18)),rgba(255,255,255,0) 55%),linear-gradient(135deg,rgba(255,255,255,.42),rgba(255,255,255,.14) 45%,rgba(255,255,255,.30));
 -webkit-backdrop-filter:blur(14px) saturate(210%) brightness(1.06);backdrop-filter:blur(14px) saturate(210%) brightness(1.06);
 border:1px solid rgba(255,255,255,.55);
 box-shadow:inset 1.5px 1.5px 0 rgba(255,255,255,.95),inset -1px -1px 0 rgba(255,255,255,.35),inset 0 -18px 30px -24px rgba(255,255,255,.7),0 30px 60px -32px rgba(60,40,140,.38),0 3px 12px rgba(60,40,140,.08)}
:root[data-skin="liquid"] .glass::after,:root[data-skin="prism"] .glass::after{content:"";position:absolute;inset:0;border-radius:inherit;pointer-events:none;
 background:linear-gradient(115deg,transparent 30%,rgba(255,255,255,.55) 45%,transparent 58%) no-repeat;background-size:250% 100%;animation:sheen 9s ease-in-out infinite;mix-blend-mode:overlay}
:root[data-skin="prism"] .glass{border:1px solid transparent;background-clip:padding-box;outline:1px solid rgba(255,255,255,.4)}
:root[data-skin="prism"] .glass::before{content:"";position:absolute;inset:-1px;border-radius:inherit;padding:1.2px;pointer-events:none;
 background:conic-gradient(from var(--ang,0deg),#ff8ad8,#86d8ff,#a3ffb9,#ffe58a,#ff8ad8);animation:spin 12s linear infinite;
 -webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0)}
@keyframes sheen{0%,55%{background-position:120% 0}100%{background-position:-120% 0}}
:root[data-skin="liquid"] .tb,:root[data-skin="prism"] .tb{background:rgba(255,255,255,.35);-webkit-backdrop-filter:blur(16px) saturate(200%);backdrop-filter:blur(16px) saturate(200%);border:1px solid rgba(255,255,255,.6)}
@media (prefers-reduced-motion:reduce){.fxblobs i,.fxaurora i,.fxsheen,:root .glass::after,:root .glass::before{animation:none!important}}
.skins{flex-wrap:wrap;max-width:300px}
.preview-tag{position:fixed;left:14px;top:10px;z-index:40;font:600 10.5px/1 var(--mono);letter-spacing:.12em;text-transform:uppercase;color:#fff;background:rgba(19,32,58,.72);padding:6px 10px;border-radius:99px;pointer-events:none}
'''
rep('</style>',CSS+'</style>')
rep('<div class="spot" aria-hidden="true"></div>','<div class="spot" aria-hidden="true"></div>\n<div class="fxblobs" aria-hidden="true"><i></i><i></i><i></i><i></i></div>\n<div class="fxaurora" aria-hidden="true"><i></i><i></i><i></i></div>\n<div class="fxsheen" aria-hidden="true"></div>\n<canvas id="fxCanvas" aria-hidden="true"></canvas>\n<div class="preview-tag">Theme preview · not saved</div>')
btns='''  <button data-skin="frost" title="Frosted glass" aria-label="Frosted glass theme" style="--s1:#dfe6ff;--s2:#d4f5ea"></button>
  <button data-skin="liquid" title="Liquid glass" aria-label="Liquid glass theme" style="--s1:#b3d2ff;--s2:#e6c6ff"></button>
  <button data-skin="borealis" title="Borealis" aria-label="Borealis theme" style="--s1:#9df0c9;--s2:#c4b0ff"></button>
  <button data-skin="biolum" title="Bioluminescent sea" aria-label="Bioluminescent sea theme" style="--s1:#9fe9f2;--s2:#a9cbff"></button>
  <button data-skin="crystal" title="Ice crystal" aria-label="Ice crystal theme" style="--s1:#ffffff;--s2:#cfe6ff"></button>
  <button data-skin="prism" title="Prism" aria-label="Prism theme" style="--s1:#ffc4e6;--s2:#bdeeff"></button>
  <button data-skin="sunset" title="Midnight-sun glass" aria-label="Midnight-sun glass theme" style="--s1:#ffcdb0;--s2:#cfd4ff"></button>
'''
a='  <button data-skin="firn" title="Firn" aria-label="Firn theme" style="--s1:#f4eee3;--s2:#d6e3ee"></button>\n'
rep(a,a+btns)
rep("const SKINS=['glacier','snow','seaice','ocean','aurora','dawn','firn'];","const SKINS=['glacier','snow','seaice','ocean','aurora','dawn','firn','frost','liquid','borealis','biolum','crystal','prism','sunset'];")
JS=r'''
/* ---------- preview: glowing background particles per theme ---------- */
(function(){const cv=document.getElementById('fxCanvas');if(!cv)return;const cx=cv.getContext('2d');let W=0,H=0,dpr=1,P=[],cfg=null,last=0;
 const CFG={
  frost:{n:70,cols:['120,140,255','90,200,170','190,140,255'],r:[1.2,3.2],vx:[-.08,.08],vy:[-.12,-.02],glow:14,tw:.6},
  liquid:{n:28,cols:['255,255,255'],r:[6,22],vx:[-.12,.12],vy:[-.15,-.03],glow:0,tw:.2,bubble:true},
  borealis:{n:110,cols:['30,200,130','120,90,255','70,180,255'],r:[.8,2.2],vx:[-.03,.03],vy:[-.02,.02],glow:12,tw:1.4},
  biolum:{n:80,cols:['0,200,220','40,140,255','60,230,180'],r:[1,3],vx:[-.05,.05],vy:[-.35,-.08],glow:16,tw:.9},
  crystal:{n:90,cols:['140,190,255','255,255,255','170,220,255'],r:[1,3.4],vx:[-.18,.18],vy:[.15,.45],glow:10,tw:1.1,flake:true},
  prism:{n:60,cols:['255,110,210','90,200,255','120,240,150','255,210,90'],r:[1.2,3],vx:[-.1,.1],vy:[-.1,.1],glow:16,tw:1},
  sunset:{n:60,cols:['255,150,90','255,110,170','150,140,255'],r:[1.2,3.2],vx:[-.06,.06],vy:[-.18,-.04],glow:16,tw:.7}};
 const R=(a,b)=>a+Math.random()*(b-a);
 const spawn=(c,any)=>({x:R(0,W),y:any?R(0,H):(c.vy[1]<=0?H+20:-20),r:R(...c.r)*1.5*dpr,vx:R(...c.vx)*dpr,vy:R(...c.vy)*dpr,col:c.cols[(Math.random()*c.cols.length)|0],ph:R(0,6.28),a:R(.55,1)});
 const size=()=>{dpr=Math.min(2,devicePixelRatio||1);W=cv.width=innerWidth*dpr;H=cv.height=innerHeight*dpr;};
 const reset=()=>{const k=document.documentElement.dataset.skin;cfg=CFG[k]||null;P=cfg?Array.from({length:cfg.n},()=>spawn(cfg,true)):[];if(!cfg)cx.clearRect(0,0,W,H);};
 size();reset();addEventListener('resize',()=>{size();reset();});
 new MutationObserver(reset).observe(document.documentElement,{attributes:true,attributeFilter:['data-skin']});
 const reduce=matchMedia('(prefers-reduced-motion: reduce)').matches;
 function frame(t){requestAnimationFrame(frame);if(!cfg||document.hidden)return;const dt=Math.min(50,t-(last||t));last=t;if(reduce&&P.drawn)return;
  cx.clearRect(0,0,W,H);
  for(const p of P){p.x+=p.vx*dt*.06;p.y+=p.vy*dt*.06;p.ph+=dt*.001*cfg.tw;
   if(p.y<-30||p.y>H+30||p.x<-30||p.x>W+30)Object.assign(p,spawn(cfg,false),{x:R(0,W)});
   const al=p.a*(.55+.45*Math.sin(p.ph));
   if(cfg.bubble){const g=cx.createRadialGradient(p.x-p.r*.35,p.y-p.r*.35,p.r*.1,p.x,p.y,p.r);g.addColorStop(0,`rgba(255,255,255,${(.55*al).toFixed(3)})`);g.addColorStop(.7,`rgba(255,255,255,${(.08*al).toFixed(3)})`);g.addColorStop(1,`rgba(255,255,255,${(.35*al).toFixed(3)})`);
    cx.fillStyle=g;cx.beginPath();cx.arc(p.x,p.y,p.r,0,7);cx.fill();cx.strokeStyle=`rgba(255,255,255,${(.5*al).toFixed(3)})`;cx.lineWidth=dpr;cx.stroke();continue;}
   cx.shadowBlur=cfg.glow*dpr;cx.shadowColor=`rgba(${p.col},${al.toFixed(3)})`;cx.fillStyle=`rgba(${p.col},${al.toFixed(3)})`;
   if(cfg.flake){cx.save();cx.translate(p.x,p.y);cx.rotate(p.ph*.3);cx.strokeStyle=cx.fillStyle;cx.lineWidth=Math.max(.6,p.r*.28);cx.beginPath();for(let k=0;k<3;k++){const a=k*Math.PI/3;cx.moveTo(-Math.cos(a)*p.r*1.6,-Math.sin(a)*p.r*1.6);cx.lineTo(Math.cos(a)*p.r*1.6,Math.sin(a)*p.r*1.6);}cx.stroke();cx.restore();}
   else{cx.beginPath();cx.arc(p.x,p.y,p.r,0,7);cx.fill();}}
  cx.shadowBlur=0;P.drawn=true;}
 requestAnimationFrame(frame);})();
'''
rep("setSkin(store.skin||'glacier',true);","setSkin(store.skin||'liquid',true);"+JS)
open(dst,'w').write(s)
print('ok',len(s))
