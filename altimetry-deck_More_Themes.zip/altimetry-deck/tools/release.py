import re
import sys,os
src=open(sys.argv[1]).read()
OUT=sys.argv[2]
K=sys.argv[3] if len(sys.argv)>3 else 'altimetry-deck:v2'
os.makedirs(OUT+'/extended',exist_ok=True);os.makedirs(OUT+'/core',exist_ok=True)
def R(s,a,b,cnt=1):
    n=s.count(a); assert n==cnt,(n,a[:80]); return s.replace(a,b)
e=R(src,"const KEY='"+K+"';","const KEY='"+K+":extended';")
e=R(e,"let store={e:{},s:{},n:{},ar:'16:9'};","let store={e:{},s:{},n:{},ar:'16:9',ext:true,gls:true};")
open(OUT+'/extended/altimetry-deck-extended.html','w').write(e)
c=R(src,"const KEY='"+K+"';","const KEY='"+K+":core';")
c=re.sub(r'<section class="slide (?:ext|gls)"[\s\S]*?</section>\s*','',c)
c=re.sub(r'<!-- =+ KEY TERMS SECTION[^>]*-->\s*','',c)
c=R(c,'<button id="btnExt" class="btn-ext" title="Polar extension slides 16–23 (X)" aria-pressed="false">Polar slides <kbd>X</kbd></button>\n <button id="btnGls" class="btn-gls" title="Key-terms slides (K)" aria-pressed="false">Key terms <kbd>K</kbd></button>','')
c=re.sub(r'<div class="jext">[\s\S]*?</div><div class="jext jgls">[\s\S]*?</div>','',c,count=1)
c=R(c,"try{const raw=localStorage.getItem(KEY); if(raw) store=Object.assign(store,JSON.parse(raw));}catch(e){}","try{const raw=localStorage.getItem(KEY); if(raw) store=Object.assign(store,JSON.parse(raw));}catch(e){}store.ext=false;store.gls=false;")
for a in ["addEventListener('keydown',e=>{if(editingText(e.target))return;if(e.key==='x'||e.key==='X')setExt(!store.ext);});",
          "addEventListener('keydown',e=>{if(editingText(e.target))return;if(e.key==='k'||e.key==='K')setGls(!store.gls);});"]:
    c=R(c,a,'')
open(OUT+'/core/altimetry-deck-core.html','w').write(c)
print('sections',e.count('<section class="slide'),c.count('<section class="slide'))
