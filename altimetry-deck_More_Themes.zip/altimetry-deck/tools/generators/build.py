import sys;sys.path.insert(0,'/home/claude/gen')
import svg1,svg2,svg3,content
from content import SLIDES,COL
FN={'g1':svg1.g1,'g2':svg1.g2,'g3':svg1.g3,'g4':svg2.g4,'g5':svg2.g5,'g6':svg2.g6,'g7':svg3.g7,'g8':svg3.g8,'g9':svg3.g9}
out=['<!-- ================= KEY TERMS SECTION (optional, K) ================= -->']
for n,S in enumerate(SLIDES,1):
    terms=''
    for k,(t,d,w) in enumerate(S['terms'],1):
        terms+=f'''   <div class="term glass rise" style="--d:{k+1};--tc:{COL[(k-1)%5]}" data-term="{k}">
    <div class="th"><span class="tn">{k}</span><h4>{t}</h4></div>
    <div data-step="{k}" class="tdx"><p class="def">{d}</p><p class="twhy"><b>Why it matters:</b> {w}</p></div>
   </div>
'''
    notes=''.join(f'<p>{x}</p>' for x in S['notes'])
    notes+='<p><b>Self-test.</b> Before each click, try to define the highlighted term in one sentence, then reveal it.</p>'
    out.append(f'''<section class="slide gls" id="{S['id']}" data-title="Terms · {S['kick']}">
 <header class="hd rise"><div class="kicker"><span class="num gl">T{n}</span><span>Key terms · {S['kick']}</span></div><h2>{S['title']}</h2></header>
 <div class="gx">
  <div class="card glass notilt rise gvis" style="--d:1">
   <svg viewBox="0 0 800 520" role="img" aria-label="{S['aria']}">{FN[S['fn']]()}</svg>
   <p class="xcap">{S['cap']} <span class="lbl">schematic · click → to reveal each term</span></p>
  </div>
  <div class="terms">
{terms}  </div>
 </div>
 <div class="foot"><span>Radar &amp; Laser Altimetry · key terms</span><span>T{n}</span></div>
 <aside class="notes">{notes}</aside>
</section>''')
open('/tmp/terms.html','w').write('\n'.join(out)+'\n')
print('ok',sum(len(x) for x in out))
