import notes_v3, copy
N=copy.deepcopy(notes_v3.N)
S={
's1':[('under Dr Sinead Farrell,','for Dr. Sinéad L. Farrell, Associate Professor in the Department of Geographical Sciences at the University of Maryland, College Park,')],
's3':[('R = cΔt/2','$R = c\\,\\Delta t/2$'),('h = H − R','$h = H - R$'),('where H is the altitude','where $H$ is the altitude'),('H is determined','$H$ is determined'),
      ('h = N + η + tides + IB','$h = N + \\eta + \\text{tides} + \\mathrm{IB}$'),('. N is the geoid','. $N$ is the geoid'),('; η is the dynamic','; $\\eta$ is the dynamic'),('while η is of','while $\\eta$ is of')],
's4':[('δR = 40.3·TEC/f²','$\\delta R_{\\mathrm{iono}} = 40.3\\,\\mathrm{TEC}/f^{2}$')],
's5':[('D = 2√[2h(δR + Hs)/(1 + h/R_E)]','$D = 2\\sqrt{2h(\\delta R + H_{\\mathrm{s}})/(1 + h/R_{\\mathrm{E}})}$'),
      ('where h is the altitude, δR the range resolution, Hs the significant wave height and R_E the Earth’s radius','where $h$ is the altitude, $\\delta R$ the range resolution, $H_{\\mathrm{s}}$ the significant wave height and $R_{\\mathrm{E}}$ the Earth’s radius'),
      ('1,336 km, D is','1,336 km, $D$ is'),('Hs = 4 m','$H_{\\mathrm{s}} = 4$ m')],
's6':[('Hs = 2.0 m','$H_{\\mathrm{s}} = 2.0$ m'),('coefficient σ⁰','coefficient $\\sigma^{0}$'),('approximately as √N','approximately as $1/\\sqrt{N}$'),('Averaging N echoes','Averaging $N$ echoes')],
's15':[('total freeboard, F_L,','total freeboard, $F_{\\mathrm{L}}$,'),('radar freeboard, F_R,','radar freeboard, $F_{\\mathrm{R}}$,'),('h_s = (F_L − F_R)/η_s','$h_{\\mathrm{s}} = (F_{\\mathrm{L}} - F_{\\mathrm{R}})/\\eta_{\\mathrm{s}}$'),
       ('where η_s, approximately 1.2,','where $\\eta_{\\mathrm{s}} \\approx 1.2$'),('With F_L = 0.50 m, F_R = 0.20 m and a snow density of 0.30 g cm⁻³','With $F_{\\mathrm{L}} = 0.50$ m, $F_{\\mathrm{R}} = 0.20$ m and a snow density $\\rho_{\\mathrm{s}} = 0.30$ g cm⁻³')],
's18':[('Δφ = 4πΔr/λ','$\\Delta\\varphi = 4\\pi\\,\\Delta r/\\lambda$'),('A displacement Δr','A displacement $\\Delta r$'),('Q = ∫h·u·C dx','$Q = \\int h\\,u\\,C\\,\\mathrm{d}x$')],
's19':[('h_i = (ρ_w F_i + ρ_s h_s)/(ρ_w − ρ_i)','$h_{\\mathrm{i}} = (\\rho_{\\mathrm{w}} F_{\\mathrm{i}} + \\rho_{\\mathrm{s}} h_{\\mathrm{s}})/(\\rho_{\\mathrm{w}} - \\rho_{\\mathrm{i}})$'),
       ('density ρ_w is','density $\\rho_{\\mathrm{w}}$ is'),('density ρ_i is','density $\\rho_{\\mathrm{i}}$ is'),('density ρ_s is','density $\\rho_{\\mathrm{s}}$ is')],
's20':[('−(ρ_w − ρ_s)/(ρ_w − ρ_i)','$-(\\rho_{\\mathrm{w}} - \\rho_{\\mathrm{s}})/(\\rho_{\\mathrm{w}} - \\rho_{\\mathrm{i}})$'),('[ρ_w(η_s − 1) + ρ_s]/(ρ_w − ρ_i)','$[\\rho_{\\mathrm{w}}(\\eta_{\\mathrm{s}} - 1) + \\rho_{\\mathrm{s}}]/(\\rho_{\\mathrm{w}} - \\rho_{\\mathrm{i}})$')],
's22':[('η = SSH − N','$\\eta = \\mathrm{SSH} - N$'),('u_g = (g/f) k̂ × ∇η','$\\mathbf{u}_{\\mathrm{g}} = (g/f)\\,\\hat{k} \\times \\nabla\\eta$')],
'g1':[('R = ct/2','$R = c\\,\\Delta t/2$'),('H is the satellite’s','$H$ is the satellite’s'),('SSH = H − R','$\\mathrm{SSH} = H - R$')],
'g3':[('σ⁰, the normalised','$\\sigma^{0}$, the normalised')],
'g8':[('Dr Farrell','Dr. Farrell')],
'g9':[('dh/dt,','$\\mathrm{d}h/\\mathrm{d}t$,')],
}
for sid,subs in S.items():
    for a,b in subs:
        hit=False
        for k,(h,t) in enumerate(N[sid]):
            if a in t: N[sid][k]=(h,t.replace(a,b));hit=True
        assert hit,(sid,a)
# check s3 "where c is"

N['s3']=[(h,t.replace('$R = c\\,\\Delta t/2$.','$R = c\\,\\Delta t/2$, where $c$ is the speed of light.')) for h,t in N['s3']]
