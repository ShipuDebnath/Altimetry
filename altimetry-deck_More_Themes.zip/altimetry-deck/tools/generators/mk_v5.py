from mk_v4 import N
import re
N['s1'][0]=(None,'This presentation, prepared by Shipu Debnath for GEOG 789: Independent Study and submitted to Dr. Sinéad L. Farrell, Associate Professor in the Department of Geographical Sciences at the University of Maryland, College Park, examines how radar and laser altimeters measure the height of the Earth’s surface from orbit.')
S={
'I will begin with the measurement principle and the choice of wavelength, then treat radar and laser altimetry in turn, compare how each interacts with different surfaces and at what spatial scale, review the mission record, and conclude with the case for combining the two.':
'The presentation proceeds from the measurement principle and the choice of wavelength to radar and laser altimetry in turn, then compares how each interacts with different surfaces and at what spatial scale, reviews the mission record, and closes with the case for combining the two.',
'To place altimetry in context, I begin with the distinction between passive and active remote sensing.':'Altimetry is best placed in context through the distinction between passive and active remote sensing.',
'I now turn to the radar altimeter, beginning with how its echo is formed.':'The radar altimeter is considered first, beginning with the formation of its echo.',
'Throughout this talk I therefore quote the conventional radar footprint as approximately 2 to 10 km, depending on sea state and altitude.':'Throughout the presentation, the conventional radar footprint is therefore given as approximately 2 to 10 km, depending on sea state and altitude.',
'I turn now to the mission record and the climate data record it has produced.':'The mission record and the climate data record it has produced are summarised here.',
'I conclude the core presentation with an example of how the two techniques are combined.':'The core presentation closes with an example of how the two techniques are combined.',
'Thank you; I welcome questions.':'Questions are welcome.',
'applies these techniques to my study region:':'applies these techniques to the study region of this independent study:',
'Altimeters measure height; to study ice dynamics we also need motion, which brings me to NISAR.':'Altimeters measure height; the study of ice dynamics also requires motion, which is the contribution of NISAR.',
'Turning to the Greenland Ice Sheet, I summarise what radar and laser altimetry show about its thinning.':'For the Greenland Ice Sheet, radar and laser altimetry together document sustained thinning.',
'that is central to my study;':'that is central to this study;',
'form part of my study region.':'form part of the study region.',
}
for sid,ps in N.items():
    for k,(h,t) in enumerate(ps):
        for a,b in S.items(): t=t.replace(a,b)
        ps[k]=(h,t)
# s1 first para may have contained "Good morning..." replaced fully above; ensure
N['g2']=[(h,t.replace('so the measured mean surface lies too low by up to several centimetres or more; it is corrected empirically from wave height and wind speed.','so the measured mean surface lies too low, typically by a few per cent of the significant wave height; it is corrected empirically from wave height and wind speed.')) for h,t in N['g2']]
