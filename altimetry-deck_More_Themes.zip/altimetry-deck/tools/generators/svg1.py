# Diagrams for term slides T1-T3. viewBox 800x520. data-k = term number(s) highlighted.
R='#2a56c6';L='#0e9a55';T='#0f8790';I='#c2364a';A='#b7791f';K='#13203a';M='#5b6b86'
def sat(x,y,s=1):
    return f'<g transform="translate({x},{y}) scale({s})"><rect x="-34" y="-6" width="24" height="12" rx="2" fill="#2a4f9e"/><rect x="10" y="-6" width="24" height="12" rx="2" fill="#2a4f9e"/><rect x="-10" y="-10" width="20" height="20" rx="3" fill="#e9b949" stroke="#8a6512"/><circle cx="0" cy="12" r="3" fill="{K}"/></g>'
def arrowdefs(id_,c):
    return f'<marker id="{id_}" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse"><path d="M0 0L10 5L0 10z" fill="{c}"/></marker>'
def lab(x,y,t,c=K,k=None,anchor='start',size=16,w=600):
    kk=f' class="gk" data-k="{k}"' if k else ''
    return f'<text x="{x}" y="{y}" fill="{c}" font-size="{size}" font-weight="{w}" text-anchor="{anchor}"{kk}>{t}</text>'

def g1():
    # measuring height: satellite, range, orbit height, ellipsoid, geoid, SSH, MSS
    import math
    def wave(y0,amp,fn,x0=40,x1=760,n=80):
        pts=[]
        for i in range(n+1):
            x=x0+(x1-x0)*i/n;pts.append(f'{x:.1f},{y0+fn(x)*amp:.1f}')
        return ' '.join(pts)
    geo=lambda x: math.sin(x/95)*.8+math.sin(x/41+1)*.35
    ssh=lambda x: geo(x)*1.0-0.55*math.exp(-((x-560)/70)**2)
    gp=wave(380,14,geo); sp=wave(352,14,ssh)
    ell='M40 470 Q400 438 760 470'
    o=[f'<defs>{arrowdefs("a1r",R)}{arrowdefs("a1k",K)}{arrowdefs("a1t",T)}<linearGradient id="g1sea" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#8fb3ec"/><stop offset="1" stop-color="#cfdcf3"/></linearGradient></defs>']
    o.append(f'<path d="M40 70 Q400 20 760 70" fill="none" stroke="#9aa9c4" stroke-dasharray="4 6"/>'+lab(44,60,'orbit',M,size=14,w=500))
    o.append(sat(400,52))
    # sea body
    o.append(f'<polygon points="{sp} 760,470 40,470" fill="url(#g1sea)" opacity=".85"/>')
    # ellipsoid
    o.append(f'<g class="gk" data-k="2"><path d="{ell}" fill="none" stroke="{K}" stroke-width="2.5"/>{lab(48,500,"reference ellipsoid (height zero)",K,size=15)}</g>')
    # geoid
    o.append(f'<g class="gk" data-k="3"><polyline points="{gp}" fill="none" stroke="{A}" stroke-width="2.5" stroke-dasharray="7 5"/>{lab(48,412,"geoid: level surface of gravity",A,size=15)}</g>')
    # sea surface
    o.append(f'<g class="gk" data-k="4 5"><polyline points="{sp}" fill="none" stroke="{R}" stroke-width="3"/>{lab(48,336,"sea surface",R,size=15)}</g>')
    # MSS dotted slightly offset
    mp=wave(352,14,lambda x:ssh(x)+.12)
    o.append(f'<g class="gk" data-k="5"><polyline points="{mp}" fill="none" stroke="{T}" stroke-width="2" stroke-dasharray="2 5"/>{lab(612,312,"mean sea surface (MSS)",T,size=15)}</g>')
    # R arrow
    ys=352+14*ssh(400)
    o.append(f'<g class="gk" data-k="1"><line x1="392" y1="70" x2="392" y2="{ys-3:.0f}" stroke="{R}" stroke-width="3" marker-end="url(#a1r)"/>{lab(372,200,"R  range",R,anchor="end",size=18,w=700)}{lab(372,222,"= c·t / 2",R,anchor="end",size=15,w=500)}</g>')
    # H arrow
    ye=470-32*(1-((400-400)/360)**2)+ 1
    o.append(f'<g class="gk" data-k="2"><line x1="416" y1="70" x2="416" y2="440" stroke="{K}" stroke-width="2.5" marker-end="url(#a1k)"/>{lab(428,200,"H  orbit height",K,size=18,w=700)}{lab(428,222,"(GNSS · DORIS · laser ranging)",M,size=14,w=500)}</g>')
    # SSH arrow at x=560
    y5=352+14*ssh(560)
    o.append(f'<g class="gk" data-k="4"><line x1="560" y1="442" x2="560" y2="{y5+3:.0f}" stroke="{R}" stroke-width="3" marker-end="url(#a1r)"/>{lab(572,402,"SSH = H − R",R,size=17,w=700)}</g>')
    # SLA bracket
    o.append(f'<g class="gk" data-k="5"><path d="M690 {352+14*ssh(690)+2:.0f} v-0" stroke="{T}"/>{lab(612,292,"SLA = SSH − MSS",T,size=15,w=700)}</g>')
    o.append(lab(760,512,'heights not to scale',M,anchor='end',size=12,w=500))
    return '\n'.join(o)

def g2():
    o=[f'<defs>{arrowdefs("a2",K)}<linearGradient id="g2ion" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e7dcf7"/><stop offset="1" stop-color="#f3eefb"/></linearGradient><linearGradient id="g2dry" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef3fb"/><stop offset="1" stop-color="#dce7f7"/></linearGradient></defs>']
    # layers
    o.append(f'<g class="gk" data-k="3"><rect x="40" y="96" width="460" height="88" rx="10" fill="url(#g2ion)"/>'+''.join(f'<circle cx="{60+i*37%440}" cy="{110+(i*23)%60}" r="2.4" fill="#7b5bb8"/>' for i in range(22))+lab(54,122,'IONOSPHERE',"#6a4aa8",size=14,w=700)+lab(54,142,'free electrons',"#6a4aa8",size=13,w=500)+'</g>')
    o.append(f'<g class="gk" data-k="1"><rect x="40" y="196" width="460" height="150" rx="10" fill="url(#g2dry)"/>{lab(54,222,"TROPOSPHERE · dry gases",R,size=14,w=700)}</g>')
    # clouds (wet)
    cl=''.join(f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="#ffffff" stroke="#b9c8e2"/>' for cx,cy,rx,ry in [(330,300,46,18),(368,290,34,16),(140,310,40,15),(176,302,28,13)])
    o.append(f'<g class="gk" data-k="2">{cl}{lab(54,330,"water vapour + cloud",T,size=14,w=700)}</g>')
    # sea with waves: troughs flatter / brighter
    import math
    pts=' '.join(f'{40+i*4},{392+9*math.cos(i*4/34*2*math.pi)+3*math.cos(i*4/17*2*math.pi)}' for i in range(116))
    o.append(f'<g class="gk" data-k="4"><polygon points="{pts} 500,470 40,470" fill="#9fbbe9"/><polyline points="{pts}" fill="none" stroke="{R}" stroke-width="2"/>'+''.join(f'<ellipse cx="{40+17+34*i}" cy="{401}" rx="10" ry="2.5" fill="#fff" opacity=".85"/>' for i in range(13))+lab(54,494,'troughs reflect more than crests → sea-state bias',R,size=14,w=600)+'</g>')
    # satellite, pulse path
    o.append(sat(270,44))
    o.append(f'<line x1="270" y1="58" x2="270" y2="384" stroke="{K}" stroke-width="2" stroke-dasharray="6 5" marker-end="url(#a2)"/>')
    # orbit tracking icons
    o.append(f'<g class="gk" data-k="5"><path d="M200 30 Q270 4 340 30" fill="none" stroke="{A}" stroke-width="2"/>{lab(350,36,"precise orbit: GNSS · DORIS · laser",A,size=13,w=600)}<circle cx="450" cy="66" r="5" fill="{A}"/><line x1="450" y1="66" x2="290" y2="46" stroke="{A}" stroke-dasharray="3 4"/></g>')
    # delay bars (log-ish visual, cm)
    bars=[(1,'Dry troposphere','≈ 2.3 m',230,R),(2,'Wet troposphere','mm → 40 cm',140,T),(3,'Ionosphere','up to 30 cm',125,'#6a4aa8'),(4,'Sea-state bias','up to tens of cm',110,R),(5,'Orbit error','≈ 1 cm (Jason)',36,A)]
    o.append(lab(540,92,'delay or error it adds',M,size=13,w=600))
    for i,(k,n,v,w,c) in enumerate(bars):
        y=118+i*76
        o.append(f'<g class="gk" data-k="{k}">{lab(540,y,n,K,size=15,w=700)}<rect x="540" y="{y+10}" width="{w}" height="14" rx="7" fill="{c}" opacity=".85"/>{lab(540+w+8 if w<150 else 540,y+44 if w>=150 else y+22,v,c,size=14,w=600)}</g>')
    o.append(lab(760,512,'bar lengths schematic (log-like)',M,anchor='end',size=12,w=500))
    return '\n'.join(o)

def g3():
    import math,random
    random.seed(4)
    X0,X1,Y0,Y1=70,740,430,80
    X=lambda g:X0+(X1-X0)*g/128; Y=lambda p:Y0-(Y0-Y1)*p
    def wf(g,swh=2.0):
        t0=44; s=1.2+1.1*swh
        e=.5*(1+math.erf((g-t0)/(s*1.414)))
        return .04+.92*e*math.exp(-max(0,g-t0)/150)
    sm=' '.join(f'{X(g):.1f},{Y(wf(g)):.1f}' for g in [i*.5 for i in range(257)])
    noisy=' '.join(f'{X(g):.1f},{Y(min(1.12,max(0.0,wf(g)*(1+0.2*random.gauss(0,1))+0.015*random.gauss(0,1)))):.1f}' for g in range(129))
    o=[f'<defs>{arrowdefs("a3",K)}{arrowdefs("a3r",I)}</defs>']
    o.append(f'<g class="gk" data-k="1"><line x1="{X0}" y1="{Y0}" x2="{X1}" y2="{Y0}" stroke="{K}" stroke-width="1.5"/><line x1="{X0}" y1="{Y0}" x2="{X0}" y2="{Y1-20}" stroke="{K}" stroke-width="1.5"/>'+''.join(f'<line x1="{X(g)}" y1="{Y0}" x2="{X(g)}" y2="{Y0+6}" stroke="{K}"/>{lab(X(g),Y0+24,str(g),M,anchor="middle",size=13,w=500)}' for g in (0,32,64,96,128))+lab((X0+X1)/2,Y0+48,'time → 128 range gates (0.47 m each in Ku)',K,anchor='middle',size=14,w=600)+f'<text x="{X0-40}" y="{(Y0+Y1)/2}" fill="{K}" font-size="14" font-weight="600" transform="rotate(-90 {X0-40} {(Y0+Y1)/2})" text-anchor="middle">echo power</text></g>')
    o.append(f'<g class="gk" data-k="3"><polyline points="{noisy}" fill="none" stroke="#9aa6bd" stroke-width="1.4"/>{lab(X(84),Y(.36),"grey: one echo (speckle)",M,size=14)}</g>')
    o.append(f'<polyline points="{sm}" fill="none" stroke="{R}" stroke-width="3.2"/>')
    o.append(lab(X(84),Y(.52),'blue: ≈ 1,000 echoes averaged',R,size=14))
    # leading edge + midpoint
    mid=44
    o.append(f'<g class="gk" data-k="2"><circle cx="{X(mid)}" cy="{Y(wf(mid))}" r="7" fill="#fff" stroke="{R}" stroke-width="3"/><line x1="{X(mid)}" y1="{Y(wf(mid))}" x2="{X(mid)}" y2="{Y0}" stroke="{R}" stroke-dasharray="4 4"/>{lab(X(mid)-10,Y(.5)-10,"mid-point → range",R,anchor="end",size=15,w=700)}{lab(X(mid)-10,Y(.5)+10,"(retracking fits a model)",M,anchor="end",size=13,w=500)}</g>')
    # rise time
    a,b=38.5,49.5
    o.append(f'<g class="gk" data-k="4"><line x1="{X(a)}" y1="{Y(.12)-5}" x2="{X(b)}" y2="{Y(.12)-5}" stroke="{I}" stroke-width="2.5" marker-start="url(#a3r)" marker-end="url(#a3r)"/>{lab(X(b)+12,Y(.12),"rise time ∝ wave height (SWH)",I,size=15,w=700)}</g>')
    # peak power
    o.append(f'<g class="gk" data-k="5"><line x1="{X(46)}" y1="{Y(.95)}" x2="{X(128)}" y2="{Y(.95)}" stroke="{T}" stroke-dasharray="6 5" stroke-width="2"/>{lab(X(60),Y(.95)-10,"peak power (σ⁰) → wind speed",T,size=15,w=700)}</g>')
    o.append(f'<line x1="{X0}" y1="{Y(.04)}" x2="{X(30)}" y2="{Y(.04)}" stroke="{M}" stroke-dasharray="3 4"/>'+lab(X(2),Y(.04)-8,'noise floor',M,size=13,w=500))
    return '\n'.join(o)
