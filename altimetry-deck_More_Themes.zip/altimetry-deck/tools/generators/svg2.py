from svg1 import *
import math,random
def g4():
    o=[f'<defs><radialGradient id="g4d"><stop offset="0" stop-color="{R}" stop-opacity=".55"/><stop offset="1" stop-color="{R}" stop-opacity=".15"/></radialGradient></defs>']
    # three panels: radar LRM, delay-Doppler, laser. Ground ellipses at y=300
    cols=[(140,'Conventional radar'),(400,'Delay-Doppler radar'),(660,'Laser')]
    for cx,t in cols: o.append(lab(cx,26,t,K,anchor='middle',size=16,w=700))
    # panel 1
    cx=140
    o.append(sat(cx,62,.9))
    o.append(f'<g class="gk" data-k="3"><path d="M{cx} 74 L{cx-118} 290 L{cx+118} 290 Z" fill="{R}" opacity=".07"/><ellipse cx="{cx}" cy="300" rx="118" ry="30" fill="none" stroke="{R}" stroke-dasharray="6 5" stroke-width="1.6"/>{lab(cx,350,"antenna beam ≈ 20+ km",M,anchor="middle",size=13,w=600)}</g>')
    o.append(f'<g class="gk" data-k="1 2"><ellipse cx="{cx}" cy="300" rx="40" ry="10.5" fill="url(#g4d)" stroke="{R}" stroke-width="2.4"/>{lab(cx,262,"pulse-limited ≈ 2 km",R,anchor="middle",size=14,w=700)}</g>')
    # panel 2: disc sliced
    cx=400
    o.append(sat(cx,62,.9))
    o.append(f'<path d="M{cx} 74 L{cx-118} 290 L{cx+118} 290 Z" fill="{R}" opacity=".05"/>')
    strips=''.join(f'<rect x="{cx-110+i*20}" y="289" width="16" height="22" rx="3" fill="{R}" opacity="{.18 if i!=5 else .7}"/>' for i in range(11))
    o.append(f'<g class="gk" data-k="4">{strips}<line x1="{cx-118}" y1="330" x2="{cx+118}" y2="330" stroke="{K}" marker-end="url(#a4)"/>{lab(cx,350,"flight direction →",M,anchor="middle",size=13,w=600)}{lab(cx,276,"strips ≈ 300 m along track",R,anchor="middle",size=14,w=700)}</g>')
    o[0]=o[0].replace('</defs>',arrowdefs('a4',K)+'</defs>')
    # panel 3 laser
    cx=660
    o.append(sat(cx,62,.9))
    o.append(f'<g class="gk" data-k="3"><line x1="{cx}" y1="74" x2="{cx}" y2="298" stroke="{L}" stroke-width="2.5"/><path d="M{cx-2} 74 L{cx-5} 298 L{cx+5} 298 L{cx+2} 74Z" fill="{L}" opacity=".25"/><ellipse cx="{cx}" cy="300" rx="6" ry="2" fill="{L}"/>{lab(cx+12,286,"11 m spot",L,size=14,w=700)}{lab(cx,350,"beam = pulse footprint",M,anchor="middle",size=13,w=600)}</g>')
    # footprint label area (term 1)
    o.append(f'<g class="gk" data-k="1"><line x1="40" y1="372" x2="760" y2="372" stroke="#d5deec"/>{lab(400,394,"footprint = the patch of ground that returns the echo",K,anchor="middle",size=14,w=600)}</g>')
    # bottom: full waveform vs photon counting
    o.append(f'<g class="gk" data-k="5">')
    o.append(lab(60,424,'Full waveform (GEDI)',K,size=14,w=700))
    pts=[]
    for i in range(121):
        y=i/120
        p=.85*math.exp(-((y-.25)/.08)**2)+.5*math.exp(-((y-.45)/.1)**2)+.95*math.exp(-((y-.85)/.035)**2)
        pts.append(f'{60+i*2.6:.1f},{506-p*55:.1f}')
    o.append(f'<polyline points="{" ".join(pts)}" fill="none" stroke="{L}" stroke-width="2.6"/>{lab(150,444,"canopy layers",L,anchor="middle",size=12,w=600)}{lab(325,444,"ground",L,anchor="middle",size=12,w=600)}')
    o.append(lab(440,424,'Photon counting (ICESat-2)',K,size=14,w=700))
    random.seed(7)
    d=''
    for i in range(70):
        x=440+i*4.4
        y=480+3*math.sin(i/9)
        d+=f'<circle cx="{x:.1f}" cy="{y+random.gauss(0,1.3):.1f}" r="2.1" fill="{L}"/>'
    for i in range(26):
        d+=f'<circle cx="{440+random.random()*310:.1f}" cy="{438+random.random()*70:.1f}" r="1.6" fill="#9aa6bd"/>'
    o.append(d+lab(756,506,'single photons + solar noise',M,anchor='end',size=12,w=500)+'</g>')
    return '\n'.join(o)

def g5():
    o=[f'<defs>{arrowdefs("a5g",L)}{arrowdefs("a5b",R)}{arrowdefs("a5k",K)}<linearGradient id="g5w" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#7ea6e3"/><stop offset="1" stop-color="#355fa8"/></linearGradient><linearGradient id="g5i" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e3f1fb"/><stop offset="1" stop-color="#a9cbe6"/></linearGradient></defs>']
    SL=250
    o.append(f'<rect x="20" y="{SL}" width="760" height="250" fill="url(#g5w)" rx="6"/>')
    def floe(x0,x1,fb,dr,sn,k='2'):
        s=f'<g class="gk" data-k="{k}"><rect x="{x0}" y="{SL-fb}" width="{x1-x0}" height="{fb+dr}" rx="6" fill="url(#g5i)" stroke="#7fa6c9"/>'
        if sn: s+=f'<rect x="{x0+2}" y="{SL-fb-sn}" width="{x1-x0-4}" height="{sn}" rx="5" fill="#fbfdff" stroke="#c9d6e6"/>'
        return s+'</g>'
    o.append(floe(30,300,30,190,16))
    o.append(floe(380,450,7,40,0,'1'))  # refrozen lead (thin ice)
    o.append(floe(470,640,26,160,14))
    # MIZ broken floes with waves
    for i,x in enumerate([660,690,712,738,760]):
        o.append(floe(x,x+18-i*2,10,40-i*5,4,'5'))
    wv=' '.join(f'{650+i*3},{SL+2+3*math.sin(i/3)}' for i in range(44))
    o.append(f'<g class="gk" data-k="5"><polyline points="{wv}" fill="none" stroke="#fff" stroke-width="1.5"/>{lab(712,SL-46,"marginal ice zone",K,anchor="middle",size=14,w=700)}{lab(712,SL-28,"← waves from open ocean",M,anchor="middle",size=12,w=600)}</g>')
    # lead
    o.append(f'<g class="gk" data-k="1"><rect x="300" y="{SL-1}" width="80" height="4" fill="#dbe9ff"/>{lab(340,SL-58,"lead",R,anchor="middle",size=17,w=700)}{lab(340,SL-40,"open water",M,anchor="middle",size=13,w=600)}{lab(415,SL-18,"refrozen lead",M,anchor="middle",size=12,w=600)}<line x1="340" y1="{SL-34}" x2="340" y2="{SL-6}" stroke="{R}" stroke-dasharray="3 3"/></g>')
    o.append(f'<line x1="20" y1="{SL}" x2="780" y2="{SL}" stroke="#fff" stroke-width="1.5" stroke-dasharray="6 5"/>'+lab(306,SL+20,'sea level',"#ffffff",size=13,w=600))
    # beams
    o.append(f'<g class="gk" data-k="3 4"><line x1="120" y1="20" x2="120" y2="{SL-46}" stroke="{L}" stroke-width="3" marker-end="url(#a5g)"/>{lab(128,40,"laser → snow top",L,size=14,w=700)}<line x1="200" y1="20" x2="200" y2="{SL-30}" stroke="{R}" stroke-width="3" marker-end="url(#a5b)"/>{lab(208,64,"radar → ice surface",R,size=14,w=700)}</g>')
    # freeboard arrows on floe1 at x=250,270
    o.append(f'<g class="gk" data-k="3"><line x1="262" y1="{SL}" x2="262" y2="{SL-44}" stroke="{L}" stroke-width="2.4" marker-end="url(#a5g)"/><line x1="282" y1="{SL}" x2="282" y2="{SL-29}" stroke="{R}" stroke-width="2.4" marker-end="url(#a5b)"/>{lab(254,SL-52,"freeboard",K,anchor="end",size=15,w=700)}</g>')
    o.append(f'<g class="gk" data-k="4"><path d="M44 {SL-46} h-10 v16 h10" fill="none" stroke="{K}" stroke-width="2"/>{lab(28,SL-56,"snow depth",K,size=13,w=700)}</g>')
    o.append(f'<g class="gk" data-k="2"><line x1="160" y1="{SL+6}" x2="160" y2="{SL+186}" stroke="#fff" stroke-width="2" marker-end="url(#a5k)" opacity=".9"/>{lab(170,SL+110,"draft: most of the ice",'#ffffff',size=14,w=700)}{lab(170,SL+128,"is under water",'#ffffff',size=14,w=700)}{lab(560,SL+86,"floe",'#13203a',anchor="middle",size=16,w=700)}</g>')
    return '\n'.join(o)

def g6():
    o=[f'<defs>{arrowdefs("a6k",K)}{arrowdefs("a6r",I)}{arrowdefs("a6b",R)}{arrowdefs("a6a",A)}</defs>']
    # cross-section top: geoid flat dashed, sea surface hump
    G=200
    hump=lambda x: 46*math.exp(-((x-300)/120)**2)
    sp=' '.join(f'{x},{G-hump(x):.1f}' for x in range(40,561,8))
    o.append(f'<polygon points="{sp} 560,250 40,250" fill="#cfdcf3"/>')
    o.append(f'<g class="gk" data-k="1"><line x1="40" y1="{G}" x2="560" y2="{G}" stroke="{A}" stroke-dasharray="7 5" stroke-width="2.2"/>{lab(48,G+20,"geoid",A,size=14,w=700)}<line x1="300" y1="{G}" x2="300" y2="{G-44}" stroke="{K}" stroke-width="2" marker-end="url(#a6k)"/>{lab(306,G-14,"≈ 1 m",K,size=14,w=700)}{lab(300,G-60,"dynamic topography",R,anchor="middle",size=15,w=700)}</g>')
    o.append(f'<polyline points="{sp}" fill="none" stroke="{R}" stroke-width="3"/>')
    # forces at x=420 slope
    o.append(f'<g class="gk" data-k="2"><line x1="420" y1="{G-26}" x2="480" y2="{G-6}" stroke="{I}" stroke-width="2.6" marker-end="url(#a6r)"/>{lab(486,G-2,"pressure push (down-slope)",I,size=13,w=700)}<line x1="420" y1="{G-26}" x2="360" y2="{G-46}" stroke="{T}" stroke-width="2.6" marker-end="url(#a6r)"/>{lab(354,G-88,"Coriolis (Earth\'s spin)",T,anchor="end",size=13,w=700)}<circle cx="420" cy="{G-26}" r="11" fill="#fff" stroke="{K}" stroke-width="2"/><circle cx="420" cy="{G-26}" r="3.5" fill="{K}"/>{lab(438,G-30-26,"current out of page",K,size=13,w=700)}</g>')
    o.append(lab(40,30,'Side view: sea level over the geoid',K,size=15,w=700))
    # plan view bottom: gyre contours
    o.append(lab(40,292,'Map view: flow follows height contours',K,size=15,w=700))
    cx,cy=230,410
    for i,(rx,ry) in enumerate([(170,90),(118,62),(68,36)]):
        o.append(f'<ellipse cx="{cx}" cy="{cy}" rx="{rx}" ry="{ry}" fill="{R}" fill-opacity="{.06+.06*i}" stroke="{R}" stroke-opacity=".5"/>')
    o.append(f'<g class="gk" data-k="3"><path d="M{cx-150} {cy-30} A160 86 0 0 1 {cx+120} {cy-66}" fill="none" stroke="{A}" stroke-width="3" marker-end="url(#a6a)"/><path d="M{cx+150} {cy+30} A160 86 0 0 1 {cx-120} {cy+66}" fill="none" stroke="{A}" stroke-width="3" marker-end="url(#a6a)"/>{lab(cx,cy+5,"HIGH",R,anchor="middle",size=16,w=800)}{lab(cx,cy+24,"gyre: clockwise round a high (N. hemisphere)",K,anchor="middle",size=12,w=600)}</g>')
    # western boundary current: tight arrows on left side
    o.append(f'<g class="gk" data-k="4"><path d="M{cx-176} {cy+60} C{cx-196} {cy+10} {cx-190} {cy-40} {cx-160} {cy-80}" fill="none" stroke="{I}" stroke-width="5" marker-end="url(#a6r)"/>{lab(cx-196,cy+86,"western boundary current",I,size=13,w=700)}{lab(cx-196,cy+102,"(e.g. Gulf Stream)",I,size=12,w=600)}</g>')
    # eddies
    o.append(f'<g class="gk" data-k="5">'+''.join(f'<circle cx="{x}" cy="{y}" r="{r}" fill="none" stroke="{T}" stroke-width="2.2"/><circle cx="{x}" cy="{y}" r="{r*.55}" fill="none" stroke="{T}" stroke-width="1.4"/>' for x,y,r in [(520,350,26),(600,420,20),(540,470,16)])+lab(520,310,'eddies: 100–300 km rings',T,size=14,w=700)+'</g>')
    # SLA panel right top small
    return '\n'.join(o)
