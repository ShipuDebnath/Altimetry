from svg1 import *
import math,random
def poly(pts,fill,stroke='#b9c6da',extra=''):
    return f'<polygon points="{" ".join(f"{x},{y}" for x,y in pts)}" fill="{fill}" stroke="{stroke}" stroke-width="1.2" {extra}/>'
def g7():
    land='#e9edf3'
    o=[f'<defs>{arrowdefs("a7r",I)}{arrowdefs("a7b",R)}{arrowdefs("a7a",A)}{arrowdefs("a7k",K)}<linearGradient id="g7s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#dfe9f8"/><stop offset="1" stop-color="#cbdcf3"/></linearGradient></defs>']
    o.append('<rect x="10" y="10" width="560" height="500" rx="12" fill="url(#g7s)"/>')
    # North America (left), Greenland (top middle), Iceland, Europe (right)
    o.append(poly([(10,10),(150,10),(160,60),(130,110),(150,150),(118,190),(110,240),(70,270),(60,330),(30,380),(10,400)],land))
    o.append(poly([(190,10),(330,10),(318,60),(300,110),(268,160),(250,190),(232,160),(214,110),(200,60)],'#f7fafd'))
    o.append(lab(262,70,'Greenland',M,anchor='middle',size=14,w=700))
    o.append(poly([(372,118),(410,110),(428,124),(404,138),(378,134)],land))
    o.append(lab(400,104,'Iceland',M,anchor='middle',size=12,w=600))
    o.append(poly([(570,10),(470,10),(458,70),(480,120),(500,150),(490,200),(520,240),(510,290),(530,330),(520,400),(570,420)],land))
    o.append(lab(536,200,'Europe',M,anchor='middle',size=13,w=700))
    o.append(lab(70,180,'Labrador',M,anchor='middle',size=12,w=600))
    # Subpolar gyre: counterclockwise loop around Labrador/Irminger seas
    o.append(f'<g class="gk" data-k="1"><ellipse cx="275" cy="225" rx="135" ry="58" fill="{R}" fill-opacity=".10" stroke="none"/><path d="M405 215 C400 168 320 160 260 176 C200 190 150 200 148 238" fill="none" stroke="{R}" stroke-width="3.5" marker-end="url(#a7b)"/><path d="M150 250 C165 285 260 292 330 278 C380 268 410 252 410 232" fill="none" stroke="{R}" stroke-width="3.5" marker-end="url(#a7b)"/>{lab(278,232,"SUBPOLAR GYRE",R,anchor="middle",size=15,w=800)}{lab(278,250,"low sea level · counter-clockwise",R,anchor="middle",size=12,w=600)}</g>')
    # subtropical gyre (clockwise)
    o.append(f'<g class="gk" data-k="2"><ellipse cx="290" cy="440" rx="190" ry="52" fill="{A}" fill-opacity=".09"/>{lab(300,470,"subtropical gyre (high, clockwise)",A,anchor="middle",size=12,w=700)}</g>')
    # Gulf Stream / NAC
    o.append(f'<g class="gk" data-k="2"><path d="M70 420 C130 380 180 360 240 340 C320 314 380 300 450 250 C480 228 492 190 488 160" fill="none" stroke="{I}" stroke-width="6" stroke-linecap="round" marker-end="url(#a7r)"/>{lab(120,372,"Gulf Stream",I,size=14,w=800)}{lab(372,322,"North Atlantic Current",I,size=13,w=700)}</g>')
    # convection sites
    def spiral(x,y):
        return f'<g transform="translate({x},{y})"><circle r="15" fill="#fff" stroke="{K}" stroke-width="1.6"/><path d="M0 -9 L0 9" stroke="{K}" stroke-width="2.2" marker-end="url(#a7k)"/></g>'
    o.append(f'<g class="gk" data-k="4">{spiral(180,214)}{spiral(330,202)}{lab(180,190,"Labrador Sea",K,anchor="middle",size=12,w=700)}{lab(334,182,"Irminger Sea",K,anchor="middle",size=12,w=700)}</g>')
    # trend chips
    o.append(f'<g class="gk" data-k="1 5"><rect x="20" y="20" width="0" height="0"/></g>')
    # AMOC inset (vertical section) right
    X0,Y0=590,40
    o.append(f'<g class="gk" data-k="3"><rect x="{X0}" y="{Y0}" width="200" height="250" rx="12" fill="#f6f8fc" stroke="#d5deec"/>{lab(X0+100,Y0+24,"AMOC (side view)",K,anchor="middle",size=14,w=800)}<rect x="{X0+12}" y="{Y0+40}" width="176" height="190" rx="6" fill="#dfe8f6"/><path d="M{X0+24} {Y0+64} H{X0+160} C{X0+176} {Y0+64} {X0+176} {Y0+80} {X0+176} {Y0+96} V{Y0+176} C{X0+176} {Y0+196} {X0+164} {Y0+204} {X0+150} {Y0+204} H{X0+30}" fill="none" stroke="{I}" stroke-width="4" marker-end="url(#a7b)"/><path d="M{X0+150} {Y0+204} H{X0+30}" fill="none" stroke="{R}" stroke-width="4"/>{lab(X0+92,Y0+58,"warm, north →",I,anchor="middle",size=12,w=700)}{lab(X0+168,Y0+140,"sinks",K,anchor="end",size=12,w=700)}{lab(X0+92,Y0+224,"← cold, deep, south",R,anchor="middle",size=12,w=700)}{lab(X0+20,Y0+250-4,"equator",M,size=11,w=600)}{lab(X0+180,Y0+250-4,"north",M,anchor="end",size=11,w=600)}</g>')
    # steric vs dynamic panel bottom right
    o.append(f'<g class="gk" data-k="5"><rect x="{X0}" y="310" width="200" height="200" rx="12" fill="#f6f8fc" stroke="#d5deec"/>{lab(X0+100,334,"Subpolar sea level",K,anchor="middle",size=14,w=800)}')
    # trend graph
    gx0,gx1,gy=X0+20,X0+182,430
    o.append(f'<line x1="{gx0}" y1="{gy}" x2="{gx1}" y2="{gy}" stroke="{M}" stroke-dasharray="3 4"/><polyline points="{gx0},{gy+30} {gx0+70},{gy-26} {gx1},{gy+40}" fill="none" stroke="{R}" stroke-width="3"/>{lab(gx0+30,gy-36,"+3.9",I,anchor="middle",size=13,w=800)}{lab(gx0+128,gy-12,"−7.1 mm/yr",R,anchor="middle",size=13,w=800)}{lab(gx0,gy+64,"1993",M,size=11,w=600)}{lab(gx0+70,gy+64,"mid-2000s",M,anchor="middle",size=11,w=600)}{lab(gx1,gy+64,"2016",M,anchor="end",size=11,w=600)}{lab(X0+100,354,"warm + expand (steric) ↑",I,anchor="middle",size=11,w=600)}{lab(X0+100,370,"cool + gyre spins up ↓",R,anchor="middle",size=11,w=600)}</g>')
    o.append(lab(20,504,'schematic, after Chafik et al. (2019)',M,size=12,w=500))
    return '\n'.join(o)

def g8():
    o=[f'<defs>{arrowdefs("a8k",K)}{arrowdefs("a8t",T)}<linearGradient id="g8s" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#c9d9f2"/><stop offset="1" stop-color="#9fbbe6"/></linearGradient></defs>']
    o.append('<rect x="10" y="10" width="780" height="500" rx="12" fill="url(#g8s)"/>')
    # reanalysis grid (term 5)
    grid=''.join(f'<line x1="{x}" y1="10" x2="{x}" y2="510" stroke="#fff" stroke-opacity=".35"/>' for x in range(50,790,40))+''.join(f'<line x1="10" y1="{y}" x2="790" y2="{y}" stroke="#fff" stroke-opacity=".35"/>' for y in range(50,510,40))
    o.append(f'<g class="gk" data-k="5">{grid}{lab(780,500,"ERA5 reanalysis grid",'#ffffff',anchor="end",size=13,w=700)}</g>')
    # sea ice at top with jagged edge
    random.seed(3)
    edge=[(10,10)]+[(10+i*26,120+random.uniform(-22,22)+ (i-15)**2*0.12) for i in range(31)]+[(790,10)]
    o.append(f'<g class="gk" data-k="1">{poly(edge,"#f4f8fd","#c9d6e6")}{lab(60,52,"sea ice (concentration ≥ 15 % → counts in extent)",K,size=14,w=700)}</g>')
    # cyclone
    cx,cy=470,330
    arms=''.join(f'<path d="{" ".join(("M" if j==0 else "L")+f"{cx+ (8+j*3.2)*math.cos(a0+j*.28):.1f} {cy+(8+j*3.2)*0.8*math.sin(a0+j*.28):.1f}" for j in range(36))}" fill="none" stroke="#ffffff" stroke-width="{3.5-k*.8}" stroke-opacity=".9"/>' for k,a0 in enumerate([0,2.1,4.2]))
    o.append(f'<g class="gk" data-k="2">{arms}<circle cx="{cx}" cy="{cy}" r="16" fill="{I}"/>{lab(cx,cy+6,"L",'#ffffff',anchor="middle",size=18,w=800)}{lab(cx+70,cy+130,"extratropical cyclone",I,anchor="middle",size=14,w=800)}</g>')
    # waves (term 3) between storm and ice edge
    wv=''
    for r in range(5):
        y=210+r*22
        wv+=f'<path d="M{300+r*10} {y} q 20 -10 40 0 t 40 0 t 40 0 t 40 0" fill="none" stroke="#fff" stroke-width="2.2" stroke-opacity="{.9-r*.12}"/>'
    o.append(f'<g class="gk" data-k="3">{wv}{lab(250,186,"waves damped inside the ice",K,size=13,w=700)}<line x1="430" y1="232" x2="430" y2="160" stroke="{K}" stroke-width="2" marker-end="url(#a8k)"/></g>')
    # altimeter tracks (term 4)
    tr=''
    for i,(x0,c) in enumerate([(80,R),(250,T),(560,L),(690,A),(380,'#6a4aa8')]):
        tr+=f'<line x1="{x0}" y1="510" x2="{x0+150}" y2="10" stroke="{c}" stroke-width="2.6" stroke-dasharray="{"" if i<4 else "8 6"}"/>'
    o.append(f'<g class="gk" data-k="4">{tr}{lab(30,488,"altimeter ground tracks: more satellites → fewer missed storms",K,size=13,w=700)}</g>')
    # buoy (term 5)
    o.append(f'<g class="gk" data-k="5"><circle cx="620" cy="420" r="9" fill="#f5c542" stroke="{K}" stroke-width="2"/><line x1="620" y1="411" x2="620" y2="396" stroke="{K}" stroke-width="2"/>{lab(634,424,"buoy",K,size=13,w=700)}</g>')
    return '\n'.join(o)

def g9():
    o=[f'<defs>{arrowdefs("a9k",K)}{arrowdefs("a9g",L)}{arrowdefs("a9b",R)}{arrowdefs("a9i",I)}<linearGradient id="g9i" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#eef6fd"/><stop offset="1" stop-color="#b9d4ec"/></linearGradient></defs>']
    # bedrock
    o.append(f'<path d="M20 470 L20 400 C180 410 360 420 520 436 C600 444 650 452 700 470 Z" fill="#c9b8a0"/>')
    # ice body surface profile
    surf=lambda x: 120+ (x-20)**2/1400 if x<620 else 0
    pts=[(x,120+((x-20)/600)**2.2*230) for x in range(20,641,10)]
    top=' '.join(f'{x},{y:.1f}' for x,y in pts)
    o.append(f'<polygon points="{top} 700,372 700,470 20,470" fill="url(#g9i)" stroke="#8fb1d1"/>')
    # ocean / fjord at right
    o.append('<rect x="640" y="372" width="150" height="110" fill="#7ea6e3"/>')
    o.append(f'<polygon points="640,352 700,360 700,384 640,392" fill="#d9e9f7" stroke="#8fb1d1"/>')
    # firn layer (term 1) along top, thinning toward margin
    firn=' '.join(f'{x},{y+ (28 if x<460 else 28*(640-x)/180):.1f}' for x,y in pts if x<=640)
    o.append(f'<g class="gk" data-k="1"><polygon points="{top.split(" 640")[0]} {" ".join(reversed(firn.split()))}" fill="#fbfaf4" stroke="#d8cfae" stroke-dasharray="3 3"/>{lab(150,170,"firn (compacting snow)",A,size=14,w=700)}</g>')
    # SMB arrows: snowfall in, melt out
    o.append(f'<g class="gk" data-k="2">'+''.join(f'<line x1="{x}" y1="40" x2="{x}" y2="{110}" stroke="{R}" stroke-width="2" stroke-dasharray="3 4" marker-end="url(#a9b)"/>' for x in (70,130,190,250))+lab(70,32,'snowfall adds mass',R,size=14,w=700)+f'<path d="M430 236 q 50 10 96 40" fill="none" stroke="{I}" stroke-width="2.4" marker-end="url(#a9i)"/>{lab(330,226,"melt + runoff",I,size=14,w=700)}</g>')
    # outlet glacier + calving
    o.append(f'<g class="gk" data-k="3"><path d="M420 330 C500 350 580 360 690 366" fill="none" stroke="{K}" stroke-width="3" marker-end="url(#a9k)"/>{lab(600,420,"outlet glacier",K,anchor="middle",size=14,w=700)}{lab(600,438,"ice flows to the ocean",K,anchor="middle",size=12,w=600)}<polygon points="720,380 744,374 752,392 728,398" fill="#eef6fd" stroke="#8fb1d1"/>{lab(744,412,"calving",K,anchor="middle",size=12,w=600)}</g>')
    # altimeter beams: laser surface, radar into firn (term 1 & 4)
    o.append(sat(330,40))
    y330=120+((330-20)/600)**2.2*230
    o.append(f'<g class="gk" data-k="4 1"><line x1="322" y1="54" x2="322" y2="{y330-2:.0f}" stroke="{L}" stroke-width="3" marker-end="url(#a9g)"/><line x1="340" y1="54" x2="340" y2="{y330+22:.0f}" stroke="{R}" stroke-width="3" stroke-dasharray="7 4" marker-end="url(#a9b)"/>{lab(314,96,"laser: surface",L,anchor="end",size=13,w=700)}{lab(348,96,"radar: enters firn",R,size=13,w=700)}</g>')
    # thinning margin (term 4)
    old=' '.join(f'{x},{y-18*max(0,(x-380)/260):.1f}' for x,y in pts if x>=380)
    o.append(f'<g class="gk" data-k="4"><polyline points="{old}" fill="none" stroke="{I}" stroke-width="2" stroke-dasharray="6 5"/>{lab(600,262,"earlier surface",I,size=13,w=700)}{lab(600,278,"→ thinning (dh/dt)",I,size=13,w=700)}</g>')
    # sea-level contribution (term 5)
    o.append(f'<g class="gk" data-k="5"><rect x="600" y="24" width="186" height="96" rx="12" fill="#ffffff" stroke="#d5deec"/>{lab(693,52,"≈ 320 Gt / yr",I,anchor="middle",size=19,w=800)}{lab(693,74,"Greenland + Antarctica",K,anchor="middle",size=12,w=600)}{lab(693,92,"2003–2019",M,anchor="middle",size=12,w=600)}{lab(693,110,"≈ 14 mm of sea level",R,anchor="middle",size=13,w=700)}</g>')
    o.append(lab(20,500,'schematic cross-section, not to scale',M,size=12,w=500))
    return '\n'.join(o)
