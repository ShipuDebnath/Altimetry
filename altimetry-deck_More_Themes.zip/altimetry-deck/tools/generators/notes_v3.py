N={}
X=None
N['s1']=[
(X,'Good morning. My name is Shipu Debnath, and this presentation, prepared for GEOG 789 under Dr Sinead Farrell, examines how radar and laser altimeters measure the height of the Earth’s surface from orbit.'),
('The measurement','Both instruments rely on the same principle. The altimeter transmits a short pulse toward the surface directly beneath it and records the time until the echo returns. That interval gives the range, and because the satellite’s position is known to about one centimetre, the range yields the height of the reflecting surface.'),
('The figure','The globe is schematic and not to scale. The blue satellite represents a conventional radar altimeter such as Jason-3 or Sentinel-6, on a 66° orbit, with a footprint of roughly 2 to 10 km depending on sea state. The green satellite represents ICESat-2, on a 92° orbit, with six laser beams and footprints of about 11 m. The two orbits already indicate one theme of the talk: the reference radar record stops at 66° latitude, whereas ICESat-2 reaches 88°.'),
('Outline','I will begin with the measurement principle and the choice of wavelength, then treat radar and laser altimetry in turn, compare how each interacts with different surfaces and at what spatial scale, review the mission record, and conclude with the case for combining the two.'),
('Sources','Cheney (2001); Escudier et al. (2018); Magruder et al. (2024).'),
]
N['s2']=[
(X,'To place altimetry in context, I begin with the distinction between passive and active remote sensing.'),
('Passive sensors','Passive sensors record energy that is already present: reflected sunlight, emitted thermal infrared radiation, or naturally emitted microwaves. Optical imagers, thermal sensors and microwave radiometers belong to this group. Their measurements describe what the surface is, in terms of radiance or temperature (Glackin, 2014).'),
('Active sensors','Active sensors transmit their own signal and record the echo. Since the transmission time is known, the delay locates the surface; active sensors therefore describe where the surface is. Radar operates by day and night and through cloud (Amani et al., 2022).'),
('Illumination and weather','The three panels show why this matters. On a clear day both classes receive a usable signal. Under overcast conditions, reflected sunlight and thermal infrared are blocked, while microwaves pass through the cloud. At night, reflected sunlight is absent, and only active instruments and emitted radiation remain available.'),
('The family of active instruments','The lower row classifies active instruments by what they measure. Synthetic aperture radar forms side-looking images; scatterometers retrieve ocean wind vectors; profilers and sounders resolve the vertical structure of clouds, aerosols and ice. Radar and laser altimeters, the subject of this talk, look vertically downward and measure range: the radar with a footprint kilometres across, the laser with spots of a few metres to tens of metres (Raney, 2014, “Radars”).'),
(X,'An altimeter is therefore best understood as an active ranging instrument: its primary product is a distance, not an image.'),
]
N['s3']=[
(X,'Every result in this talk rests on the principle summarised here.'),
('Range and height','The range follows from the two-way travel time, R = cΔt/2. The surface height above the reference ellipsoid is then h = H − R, where H is the altitude of the satellite above the same ellipsoid (Magruder et al., 2024; Cheney, 2001). The readout gives the travel time and range for each mission altitude shown: Sentinel-6 at 1,336 km, SWOT at 891 km, CryoSat-2 at 717 km and ICESat-2 at 496 km.'),
('Orbit determination','H is determined by precise orbit determination, combining three independent tracking systems: GNSS receivers on board, satellite laser ranging from ground stations, and the DORIS network of radio beacons. For the Jason series the radial orbit error is about 1 to 2 cm (Cheney, 2001; Escudier et al., 2018).'),
('Range corrections','The atmosphere delays the pulse, so the uncorrected range is too long. The dry troposphere contributes about 2.3 m, water vapour from a few millimetres to about 40 cm, and the ionosphere a few centimetres, reaching about 30 cm at solar maximum. The sea-state bias is a further radar-specific correction. Each is modelled or measured and removed (Escudier et al., 2018).'),
('Components of sea-surface height','Over the ocean, the corrected height can be written h = N + η + tides + IB. N is the geoid, the gravitational equipotential surface that a motionless ocean would follow; η is the dynamic topography associated with ocean circulation; the tides are removed using models; and IB is the inverse-barometer response of the sea surface to atmospheric pressure. The geoid undulates by tens of metres, about one hundred times more than the oceanographic signal, while η is of the order of ±1 m (Cheney, 2001; Escudier et al., 2018).'),
('Timing requirement','A range change of one centimetre corresponds to 66.7 picoseconds of two-way travel time, whereas the full round trip lasts about 8.9 ms from Sentinel-6 and 3.3 ms from ICESat-2. Centimetre-level heights therefore require timing about eight orders of magnitude finer than the travel time itself, together with centimetre-level orbits and corrections.'),
]
N['s4']=[
(X,'The next consideration is the choice of wavelength, which determines much of an altimeter’s performance.'),
('Bands in use','Laser altimeters operate at 532 nm, as on ICESat-2, and at 1064 nm, as on ICESat and GEDI. Radar altimeters operate mainly in the Ku band, at 13.6 GHz or a wavelength of 2.2 cm, used by the Jason series, Sentinel-3, Sentinel-6 and CryoSat-2, and in the Ka band, at 35.75 GHz or 8.4 mm, used by SARAL/AltiKa, SWOT and the forthcoming CRISTAL. The C band at 5.3 GHz and, on Envisat, the S band at 3.2 GHz have served as secondary frequencies. The L band at 1.26 GHz is shown for reference only; it is used by the NISAR imaging radar rather than by altimeters (Escudier et al., 2018).'),
('Ionospheric delay','Free electrons in the ionosphere delay a radio signal by δR = 40.3·TEC/f², where TEC is the total electron content along the path. Because of the inverse-square dependence on frequency, the delay is about seven times smaller in Ka band than in Ku band and is negligible at optical wavelengths. It also scales with TEC, which is low on a quiet night and high near solar maximum. Dual-frequency measurement in Ku and C bands allows the delay to be estimated directly (Escudier et al., 2018; Amani et al., 2022).'),
('Ku band','Ku band has been the standard frequency for ocean altimetry. It operates through cloud and most rain, and its ionospheric delay can be removed using the C-band channel (Fischer et al., 2024).'),
('Ka band','Ka band provides finer range resolution, with range gates of about 0.3 m rather than 0.47 m, a smaller footprint and shallower penetration into snow. Its principal limitation is greater attenuation by rain (Escudier et al., 2018).'),
('Laser','Lasers provide the finest spatial sampling, with footprints of 10 to 25 m and no ionospheric delay, but they cannot measure through cloud (Magruder et al., 2024; Amani et al., 2022).'),
(X,'In short, wavelength sets the balance between all-weather coverage and spatial detail.'),
]
N['s5']=[
(X,'I now turn to the radar altimeter, beginning with how its echo is formed.'),
('Echo formation','The transmitted pulse expands as a spherical shell. It first reaches the surface at nadir, and the illuminated area then grows as a disc; this growth produces the steep leading edge of the waveform. Once the full pulse length has reached the surface, the illuminated area becomes an annulus of nearly constant area that moves outward into the weaker part of the antenna pattern, producing the slowly decaying trailing edge.'),
('Range resolution','After pulse compression, a 320 MHz chirp bandwidth gives a range resolution of 0.47 m on Poseidon-3 (Escudier et al., 2018). The instrument records only a short window of about 128 range samples around the leading edge.'),
('The pulse-limited footprint','The disc illuminated at the end of the leading edge defines the pulse-limited footprint, given by D = 2√[2h(δR + Hs)/(1 + h/R_E)], where h is the altitude, δR the range resolution, Hs the significant wave height and R_E the Earth’s radius (Chelton et al., 1989). At the Jason and Sentinel-6 altitude of 1,336 km, D is about 2 km over a calm sea, 6.3 km at Hs = 4 m and about 10 km in high seas. From the lower orbit of CryoSat-2 the corresponding values are somewhat smaller. Throughout this talk I therefore quote the conventional radar footprint as approximately 2 to 10 km, depending on sea state and altitude.'),
('Speckle and averaging','Each echo is the coherent sum of returns from many scattering facets with random phases, so individual echoes are dominated by speckle noise. Altimeters therefore transmit at roughly 2 to 9 kHz and average many echoes; Raney (2014) notes that 1,500 or more independent looks are combined each second.'),
(X,'This kilometre-scale footprint is the fundamental spatial limit of conventional radar altimetry, and it recurs in every comparison that follows.'),
]
N['s6']=[
(X,'The recorded echo, or waveform, is the basic radar altimeter measurement. Three geophysical quantities are derived from it in three steps.'),
('Recording','The altimeter records echo power as a function of time in about 128 range gates, each corresponding to 0.47 m of range in Ku band (Escudier et al., 2018).'),
('Retracking','A model waveform, over the ocean the Brown (1977) model, is fitted to the recorded echo. This procedure is known as retracking (Escudier et al., 2018).'),
('Interpretation','The mid-point of the leading edge gives the two-way travel time, and hence sea-surface height. The slope of the leading edge gives significant wave height, because higher waves spread the arrival times and lengthen the rise; the example shown corresponds to Hs = 2.0 m. The peak power, or backscatter coefficient σ⁰, gives wind speed, because a wind-roughened surface scatters energy away from nadir (Raney, 2014; Cheney, 2001). In the Bering Sea, altimeter wave heights agreed with NOAA buoys to within about 0.27 to 0.28 m, with correlations of 0.98 to 0.99 (Fischer et al., 2024).'),
('Averaging','A single echo is dominated by speckle. Averaging N echoes reduces the noise approximately as √N, which is why about 1,000 waveforms are combined into each 1 Hz measurement (Fischer et al., 2024). The panel compares averages of 1, 10, 100 and 1,000 echoes.'),
('Dependence on the surface','Waveform shape varies with the reflecting surface. The open ocean produces the classical Brown shape. Calm water in a sea-ice lead produces a narrow, intense specular return. An ice sheet produces an extended trailing edge, because Ku-band energy penetrates dry snow and firn and is scattered within the volume. Near coasts, land enters the footprint and introduces spurious peaks; this is why coastal and land retracking require specialised algorithms.'),
(X,'A single waveform thus provides height, wave height and wind speed, provided the retracker is matched to the surface.'),
]
N['s7']=[
(X,'Radar altimetry is now practised in three geometries, shown here from left to right.'),
('Conventional, pulse-limited mode','In low-resolution mode, each echo integrates over a disc of approximately 2 to 10 km, depending on sea state, within an antenna beam about 30 km wide. This mode, used by Jason-3 and SARAL/AltiKa, performs well over the open ocean but frequently includes land near the coast (Cheney, 2001; Raney, 2014).'),
('Delay-Doppler mode','In delay-Doppler, or SAR, mode the radar transmits bursts of coherent pulses and sorts the echoes by Doppler frequency. This divides the footprint into along-track cells about 300 m long, while the across-track width remains about 1.6 km. Each cell is observed repeatedly as the satellite passes, and combining these looks approximately halves the height noise (Raney, 1998; Raney, 2014). The mode is used by CryoSat-2, Sentinel-3 and Sentinel-6.'),
('Wide-swath interferometry','SWOT carries two Ka-band antennas separated by a 10 m boom. The phase difference between the echoes received at the two antennas gives the look angle, and therefore the height of each pixel, across two 50 km swaths. A conventional nadir altimeter covers the 20 km gap between them. The result is the first two-dimensional measurement of sea-surface height, in which individual eddies can be followed as they cross the swaths (Morrow et al., 2019).'),
(X,'Radar altimetry has thus progressed from a single footprint of several kilometres, to cells 300 m long, to two-dimensional swaths.'),
]
N['s8']=[
(X,'Laser altimetry operates on the same timing principle, but the instrument design is quite different.'),
('Measurement chain','ICESat-2 carries the ATLAS instrument, which emits 10,000 pulses of 532 nm light per second. A diffractive element splits each pulse into six beams. Each beam illuminates a ground spot about 11 m in diameter, and consecutive spots are 0.7 m apart along track, so they overlap to form continuous profiles. A 0.8 m telescope collects the returning light, single-photon detectors register each arrival, and the time of flight of each photon gives its height (Magruder et al., 2024; Neumann et al., 2019).'),
('Photon budget','Of the roughly 300 trillion photons in each transmitted pulse, only about a dozen are detected on return. ICESat-2 therefore records individual photon arrivals rather than a full waveform.'),
('Beam geometry','The six beams are arranged in three pairs about 3.3 km apart. Within each pair, a strong and a weak beam, with an energy ratio of about 4:1, are separated by 90 m across track, which allows the local cross-track slope to be estimated. The arrangement is reversed when the spacecraft performs its twice-yearly yaw manoeuvre.'),
('GEDI','GEDI, mounted on the International Space Station, uses three 1064 nm lasers to produce four beams, which are dithered to generate eight ground tracks 600 m apart. Footprints are 25 m in diameter and spaced about 60 m along track, and the full return waveform is recorded for each shot. GEDI therefore samples forest structure rather than mapping it continuously (Magruder et al., 2024; Dubayah et al., 2020).'),
('Historical note','Bufton (1989) set out the principles of space laser altimetry and the advantage of small footprints; the first such instruments flew on Apollo 15 to 17.'),
(X,'The two missions represent complementary designs: photon counting for dense, fine-scale profiles, and full-waveform recording for vegetation structure.'),
]
N['s9']=[
(X,'This slide shows what laser altimetry data look like in practice.'),
('Photon clouds','Each point represents a single detected photon. Dense bands mark reflecting surfaces, while scattered points are solar background, which is substantially lower at night than in daylight. Three scenes are shown. Over forest, the vertical separation between canopy and ground photons gives canopy height. Over sea ice, floes stand above the water surface in leads, and that height difference is the freeboard. In clear shallow water, green light reaches the seabed at depths up to about 50 m (Magruder et al., 2024); the apparent depth must be divided by about 1.34 to correct for refraction.'),
('Profile and three-dimensional view','The profile and the block diagram represent the same 600 m segment, sampled by one strong and one weak beam 90 m apart, and share the same vertical exaggeration: 49.7 for sea ice, 4.1 for forest and 6.2 for shallow water. The grey points indicate structure that the laser did not sample, a reminder that ICESat-2 produces profiles rather than maps.'),
('GEDI waveforms','A GEDI shot returns a single waveform from a 25 m footprint. Energy from the upper canopy arrives first, followed by returns from the mid-canopy and understorey and finally from the ground. Relative-height metrics summarise the waveform: RH98 approximates canopy height and RH50 the median energy height, and these metrics are used to estimate above-ground biomass (Dubayah et al., 2020).'),
('Data products','For ICESat-2, ATL03 contains the geolocated photons from which all higher-level products derive; ATL06 provides land-ice height, ATL07 and ATL10 sea-ice height and freeboard, ATL08 terrain and canopy height, and ATL13 inland water height. For GEDI, L2A provides the relative-height metrics and L4A and L4B provide footprint-level and gridded biomass.'),
(X,'Photon counting resolves fine-scale profiles across many surface types, while full-waveform recording captures the vertical structure of vegetation (Magruder et al., 2024, Box 1).'),
]
N['s10']=[
(X,'An important consequence of the difference in wavelength is that radar and laser altimeters observing the same location may reflect from different physical surfaces.'),
('Open ocean','Over the open ocean both instruments measure the mean sea surface.'),
('Sea ice with snow','The laser reflects from the top of the snow cover. Ku-band radar largely penetrates cold, dry snow and reflects near the snow–ice interface. The difference between the two provides an estimate of snow depth.'),
('Ice sheets','Radar returns include surface reflection and volume scattering within the firn, which biases elevations low by decimetres to metres. The laser measures the snow surface.'),
('Forest','The radar footprint integrates canopy and ground together, whereas the laser records both the canopy top and, through gaps, the ground.'),
('Coasts and shallow water','Land within the radar footprint contaminates the echo, although delay-Doppler processing reduces the effect. Green laser light can reach the seabed in clear water to about 50 m.'),
('Cloud','The cloud case over the ice sheet illustrates the principal limitation of the laser: optically thick cloud blocks the beam, while the radar continues to measure (Amani et al., 2022).'),
('A caveat','The assumption that Ku-band radar reaches the snow–ice interface breaks down for warm, wet or saline snow, which reflects the signal from within the snowpack.'),
(X,'These differing reflecting horizons introduce error when they are ignored, but they become a source of information when the two measurements are combined (Magruder et al., 2024).'),
]
N['s11']=[
(X,'To compare spatial scales directly, this slide places each footprint on a single 12 km by 12 km tile at true scale.'),
('The layers','The blue disc is a conventional radar footprint of about 2 km diameter, or 3.2 km², corresponding to a calm sea; the outer ring indicates its size at a significant wave height of 4 m. A delay-Doppler cell covers about 0.3 by 1.6 km, or 0.49 km². The green lines are the three ICESat-2 beam pairs, 3.3 km apart, each spot covering about 95 m². GEDI footprints of 25 m, or 491 m², are drawn at twice their true size for visibility. The amber strip is a single 120 m swath of the planned EDGE mission. The scale bar shows 2 km and the grid spacing is 1 km.'),
('True-scale inset','The inset shows an area of 200 by 120 m drawn at true scale, all of it lying within a single radar footprint, with ICESat-2 spots and complete GEDI footprints.'),
('Ratio of areas','About 34,000 ICESat-2 footprints fit within one calm-sea radar footprint, that is, 3.2 km² divided by roughly 95 m². In high seas, with a radar footprint near 10 km, the ratio exceeds 800,000. The radar averages over this entire area, which is appropriate for the open ocean but smooths out leads, crevasses and canopy gaps that the laser resolves (Bufton, 1989; Cheney, 2001; Magruder et al., 2024).'),
(X,'Footprint area, spanning more than four orders of magnitude, largely determines which surface features each sensor can resolve.'),
]
N['s12']=[
(X,'I turn now to the mission record and the climate data record it has produced.'),
('Radar missions','Seasat in 1978 demonstrated satellite radar altimetry, and Geosat, from 1985 to 1990, mapped the marine geoid. TOPEX/Poseidon, launched in 1992, began the high-precision reference record, which was continued by Jason-1, Jason-2, Jason-3, Sentinel-6 in 2020 and Sentinel-6B, launched on 17 November 2025. ERS-1, ERS-2 and Envisat extended coverage toward the poles; CryoSat-2, launched in 2010, was designed for the cryosphere; SARAL/AltiKa, in 2013, was the first Ka-band altimeter; and Sentinel-3 and SWOT followed.'),
('Laser missions','ICESat operated from 2003 to 2009, and ICESat-2 and GEDI have operated since 2018 (Magruder et al., 2024).'),
('Planned missions','CRISTAL, planned for 2027 to 2028, Sentinel-6C, around 2030, and EDGE, in 2030 to 2031, will extend the record.'),
('Global mean sea level','The reference missions show that global mean sea level rose by about 11 cm between 1993 and 2023, and that the rate of rise approximately doubled over that period, from about 2.1 to 4.5 mm per year (Hamlington et al., 2024). The curve shows the smoothed trend.'),
('The value of multiple missions','Record continuity depends on overlapping reference missions, and sampling improves with the number of satellites in orbit. Fischer et al. (2024) found that five or more altimeters were needed to sample every winter storm in the Bering Sea. Regional records may also depart markedly from the global mean: in the North Atlantic subpolar gyre, sea level has fallen by about 7.1 mm per year since the mid-2000s (Chafik et al., 2019).'),
(X,'Radar altimetry has thus supplied a continuous climate record since 1992, and laser altimetry has added a polar and terrestrial record since 2003.'),
]
N['s13']=[
(X,'The next generation of missions extends altimetry from profiles to swaths.'),
('SWOT','The Surface Water and Ocean Topography mission, a partnership of NASA, CNES, the Canadian Space Agency and the UK Space Agency, has operated since 2022. It measures a 120 km swath, comprising two 50 km swaths separated by a 20 km nadir gap, and maps ocean eddies, rivers and lakes in two dimensions.'),
('CRISTAL','The Copernicus Polar Ice and Snow Topography Altimeter, to be launched by ESA in 2027 to 2028, will be the first interferometric altimeter operating in both Ku and Ka bands. Because Ka-band energy reflects near the snow surface and Ku-band energy near the snow–ice interface, snow depth and sea-ice thickness can be retrieved from a single platform. Magruder et al. (2024) identify dual-band radar as a promising route to improved snow depth. CRISTAL will also continue the CryoSat-2 record.'),
('EDGE','EDGE, selected by NASA in January 2026 as an Earth System Explorer for launch in 2030 to 2031, will be the first global swath-imaging lidar, mapping five strips each 120 m wide over ice-sheet margins, glaciers and forests. Magruder et al. (2024) noted that no laser altimetry mission was planned beyond ICESat-2 and GEDI; EDGE addresses that gap.'),
('Coverage per pass','The lower chart compares the width observed on each pass, from about 66 m for ICESat-2 to 2 to 10 km for a nadir radar and about 100 km for SWOT.'),
(X,'Both radar and laser altimetry are therefore moving from measuring lines to measuring surfaces.'),
]
N['s14']=[
(X,'This slide brings the preceding material together in a direct comparison.'),
('Error budget','The left panel compares the principal corrections on a logarithmic scale. Both techniques share the dry-troposphere correction, of about 2.3 m, and the orbit error, of about 1 to 3 cm. Water vapour, the ionosphere, sea-state bias and penetration into snow are predominantly radar issues, whereas scattering by thin cloud affects only the laser (Escudier et al., 2018).'),
('Wavelength and footprint','Radar wavelengths are of the order of centimetres to millimetres, laser wavelengths of the order of a micrometre. The radar footprint is about 2 to 10 km in conventional mode and about 0.3 by 1.6 km in delay-Doppler mode, compared with 11 m for ICESat-2 and 25 m for GEDI (Bufton, 1989; Escudier et al., 2018; Magruder et al., 2024).'),
('Signal and weather','The radar records an averaged echo waveform; the laser records individual photons or a full waveform. Radar operates in all weather, day and night, whereas the laser is blocked by cloud (Amani et al., 2022).'),
('Penetration and applications','Radar penetrates snow and firn; laser light passes through canopy gaps and clear water (Magruder et al., 2024). Radar is best suited to sea level, waves and ice volume, and the laser to fine-scale ice features, canopy height and shallow bathymetry.'),
('Record length','The radar record has been continuous since 1992; the laser record covers 2003 to 2009 and 2018 onward.'),
(X,'Almost every difference in the table follows from wavelength, and the strengths of each technique correspond closely to the limitations of the other.'),
]
N['s15']=[
(X,'I conclude the core presentation with an example of how the two techniques are combined.'),
('Snow depth from two freeboards','The laser measures the total freeboard, F_L, the height of the snow surface above local sea level. The radar measures the radar freeboard, F_R, close to the ice surface but slightly reduced because the signal travels more slowly through snow. Snow depth is then h_s = (F_L − F_R)/η_s, where η_s, approximately 1.2, accounts for the slower propagation (Kwok et al., 2020). With F_L = 0.50 m, F_R = 0.20 m and a snow density of 0.30 g cm⁻³, the snow depth is approximately 24 cm.'),
('Conclusions','First, radar altimetry provides the all-weather record that has run continuously since 1992. Second, laser altimetry provides metre-scale detail of ice, vegetation and the seabed. Third, the forthcoming missions, SWOT, CRISTAL and EDGE, extend both techniques into two dimensions.'),
('Anticipated questions','If asked why lasers alone are not sufficient: cloud covers about two-thirds of the Earth at any given time. If asked why radar alone is not sufficient: its footprint is too large to resolve forest structure, narrow glaciers or individual leads.'),
('References','References 1 to 10 are the course readings; references 11 to 25 are additional sources. Thank you; I welcome questions.'),
]
N['s16']=[
(X,'The following section applies these techniques to my study region: the Arctic Ocean, Greenland and the North Atlantic.'),
('Circulation','The schematic polar stereographic map shows the principal pathways. Warm Atlantic water flows north along Norway and enters Fram Strait as the West Spitsbergen Current. The Transpolar Drift carries sea ice across the pole and out through Fram Strait into the East Greenland Current. The anticyclonic Beaufort Gyre stores freshwater in the western Arctic.'),
('Latitude limits','For a nadir-looking altimeter, the maximum latitude observed equals 180° minus the orbital inclination. CryoSat-2, ICESat-2 and CRISTAL reach 88° N; Sentinel-3 reaches 81.4° N; Jason-3 and Sentinel-6 reach only 66° N and therefore do not observe the Arctic Ocean. NISAR, a left-looking imaging radar, reaches 77.5° N, so Sentinel-1 provides coverage of the high Arctic (Magruder et al., 2024).'),
('Recent conditions','The September 2025 sea-ice minimum was 4.60 million km², tied for the tenth lowest in the satellite record, and the nineteen lowest minima have all occurred between 2007 and 2025 (NSIDC). Greenland lost 129 Gt of ice in 2025, less than its 2003–2024 mean of 219 Gt per year but still a net loss (NOAA Arctic Report Card).'),
(X,'In the Arctic, orbital inclination determines coverage, and only a small number of missions observe the central Arctic Ocean.'),
]
N['s17']=[
(X,'Altimeters measure height; to study ice dynamics we also need motion, which brings me to NISAR.'),
('Instrument','NISAR is an imaging radar rather than an altimeter: it views the surface obliquely and forms images. It carries NASA’s L-band radar, at a wavelength of 24 cm, and ISRO’s S-band radar, at about 10 cm, the first pairing of these two frequencies on one satellite, behind a 12 m deployable reflector.'),
('Orbit and coverage','The satellite flies a 747 km dawn–dusk orbit inclined at 98.4°, images a 242 km swath and revisits every 12 days, with pixel sizes of 3 to 10 m depending on mode. It was launched on 30 July 2025, and calibrated L-band data have been publicly available since 20 July 2026.'),
('SweepSAR','A wide swath ordinarily comes at the expense of resolution. NISAR avoids this trade-off: on transmission the antenna illuminates the full 242 km swath, and on reception a narrow beam electronically follows the echo from near range to far range.'),
('Polar coverage','A side-looking radar observes only one side of its ground track. Looking left provides complete coverage of Antarctica but limits Arctic coverage to 77.5° N. NISAR looks left, so Sentinel-1 and other radars are required for the high Arctic.'),
(X,'NISAR therefore contributes frequent, high-resolution measurements of surface motion, although not at the highest Arctic latitudes.'),
]
N['s18']=[
(X,'This slide describes the two methods by which imaging radar measures ice motion, and how motion and altimetry combine to give ice flux.'),
('Interferometry','The phase of a radar echo depends on the distance to the surface. A displacement Δr between two acquisitions changes the phase by Δφ = 4πΔr/λ, so each fringe corresponds to half a wavelength of motion along the line of sight: 12 cm at L band, about 5 cm at S band and about 2.8 cm at C band. L band therefore produces more widely spaced fringes and retains coherence longer over snow and ice. Over the fast-flowing trunk of a glacier, twelve days of motion produces fringes too dense to resolve. The interferogram shown is synthetic.'),
('Feature tracking','Feature tracking identifies the same surface pattern in two images and measures its displacement. It is suited to fast glaciers and drifting sea ice; NISAR’s sea-ice requirement is a resolution of 100 m per day on a 5 km grid.'),
('Ice flux','The ice volume flux through a gate is Q = ∫h·u·C dx, combining thickness from altimetry, drift velocity from radar and ice concentration, integrated across the gate. Through Fram Strait the flux averaged about 2,400 km³ per year over 1992–2014 (Spreen et al., 2020). Because Fram Strait lies north of NISAR’s coverage limit, drift there is obtained from Sentinel-1.'),
(X,'Altimetry supplies thickness, imaging radar supplies drift, and together they quantify the export of ice from the Arctic.'),
]
N['s19']=[
(X,'Sea-ice thickness cannot be measured directly from orbit; it is inferred from freeboard.'),
('Hydrostatic balance','Sea ice floats in hydrostatic equilibrium, so its freeboard constrains its total thickness: h_i = (ρ_w F_i + ρ_s h_s)/(ρ_w − ρ_i). Here the seawater density ρ_w is 1024 kg m⁻³, the ice density ρ_i is 917 kg m⁻³ for first-year and 882 kg m⁻³ for multiyear ice, and the snow density ρ_s is 300 kg m⁻³ (Alexandrov et al., 2010). Because the denominator is small, about 90 % of the ice lies below the waterline, and 1 cm of freeboard corresponds to roughly 10 cm of thickness.'),
('Sensor reference surfaces','The laser measures the total freeboard to the snow surface; Ku-band radar measures to near the snow–ice interface, with a small correction for slower propagation in snow. Additional snow loading depresses the floe, and sufficient snow can reduce the freeboard to zero and flood the ice surface.'),
('Leads as the sea-level reference','Freeboard requires the local sea level, which is obtained from leads. Calm lead water produces a sharp specular radar return, whereas rough, snow-covered floes produce a diffuse echo; the pulse peakiness parameter is used to distinguish the two (Laxon et al., 2013; Magruder et al., 2024).'),
(X,'Since a 1 cm error in sea level or freeboard propagates into about 10 cm of thickness, centimetre-level ranging is essential.'),
]
N['s20']=[
(X,'Snow on sea ice is the largest single source of uncertainty in thickness retrievals.'),
('Observed snow depth','By differencing ICESat-2 and CryoSat-2 freeboards across the Arctic, Kwok et al. (2020) found mean snow depth increasing from 9 cm in late October to 19 cm in April, with greater depths on multiyear ice, 14 to 27 cm, than on first-year ice, 5 to 17 cm. Snow accounted for about half of the laser freeboard in every month.'),
('Opposite sensitivities','An error in the assumed snow depth changes the laser-derived thickness by −(ρ_w − ρ_s)/(ρ_w − ρ_i), about −6.8 per unit for first-year ice, and the radar-derived thickness by [ρ_w(η_s − 1) + ρ_s]/(ρ_w − ρ_i), about +5.1 per unit. A 5 cm snow error therefore produces about −34 cm of error for the laser and +25 cm for the radar.'),
('Combining sensors','Because these errors are of opposite sign, combining laser and radar constrains snow depth and ice thickness jointly. This principle underlies the orbit alignment of CryoSat-2 and ICESat-2 and the dual-band design of CRISTAL. It assumes that the radar reaches the snow–ice interface, which may fail for saline or wet snow (Kacimi & Kwok, 2020).'),
('Context','Laser and radar altimetry together indicate that Arctic winter sea-ice volume decreased by about 6,000 km³, roughly one third, between 2003 and 2021 (Magruder et al., 2024).'),
]
N['s21']=[
(X,'Turning to the Greenland Ice Sheet, I summarise what radar and laser altimetry show about its thinning.'),
('Observed change','A joint ESA–NASA analysis found that CryoSat-2 and ICESat-2 elevation changes agree to within 3 %. Between 2010 and 2023 the ice sheet thinned by 1.2 m on average and by 6.4 m in the ablation zone, where summer melt exceeds accumulation, with maximum thinning of 67 m at Sermeq Kujalleq, also known as Jakobshavn Isbræ, and 75 m at Zachariæ Isstrøm (CPOM, 2024).'),
('Spatial pattern','The schematic map shows the consistent pattern: little change in the high interior and the strongest thinning along the margins and fast-flowing outlet glaciers. North of 77.5° N, Sentinel-1 rather than NISAR observes glacier flow.'),
('Along-flow profile','The illustrative profile shows thinning greatest near the calving front, about 4 to 6 m per year at Jakobshavn and Kangerlussuaq (Smith et al., 2020), and decreasing inland. The record combines ICESat from 2003 to 2009, CryoSat-2 from 2010 and ICESat-2 from 2018.'),
('Radar and laser over ice sheets','Radar operates in all weather, but over sloping terrain its kilometre-scale footprint returns the echo from the point of closest approach rather than from nadir, and it penetrates dry firn. The laser resolves 11 m footprints on steep margins and reflects from the surface, but it is interrupted by cloud (Magruder et al., 2024).'),
('From elevation to mass','Volume change multiplied by density gives mass change, and the choice of density, whether of ice or firn, is a principal source of uncertainty. Greenland and Antarctica together lost about 320 Gt per year over 2003–2019, equivalent to about 14 mm of global sea-level rise (Magruder et al., 2024, citing Smith et al., 2020).'),
]
N['s22']=[
(X,'This slide links altimetric measurements beneath the Arctic sea ice to freshwater storage and to the North Atlantic.'),
('Sea level from leads','In ice-covered regions, a radar altimeter observes the ocean surface only through leads. Specular lead echoes sample sea level, while diffuse floe echoes provide freeboard.'),
('Dynamic topography and geostrophic flow','Subtracting the geoid from sea-surface height gives the dynamic topography, η = SSH − N, and its gradient gives the geostrophic velocity, u_g = (g/f) k̂ × ∇η. The Beaufort Gyre appears as a dome of elevated sea level with anticyclonic circulation, supported by a thick layer of low-density freshwater.'),
('Freshwater and ice export','Combining radar altimetry with GRACE, Armitage et al. (2016) estimated that the Beaufort Gyre had accumulated about 4,600 km³ of freshwater by 2010 relative to 2003–2006. CryoSat-2 now provides monthly fields of Arctic sea level and geostrophic currents to 88° N (Doglioni et al., 2023). Sea-ice export through Fram Strait averaged about 2,400 km³ per year over 1992–2014, declining by about 27 % per decade (Spreen et al., 2020).'),
('Connection to the North Atlantic','Arctic freshwater exits through Fram Strait and Davis Strait toward the Labrador and Irminger Seas, where winter convection contributes to the Atlantic Meridional Overturning Circulation. Increased freshwater input could reduce surface density and weaken convection, although this remains an open question. Altimetry already documents strong decadal variability in the region: subpolar-gyre sea level rose by about 3.9 mm per year from the early 1990s and fell by about 7.1 mm per year from the mid-2000s, as the gyre first warmed and then cooled and intensified (Chafik et al., 2019).'),
]
N['s23']=[
(X,'To close the polar section, four points summarise the role of altimetry in this region.'),
('Height and thickness','Radar and laser altimeters measure sea level in leads, sea-ice freeboard and thus thickness, and ice-sheet elevation change.'),
('Motion','Imaging radars such as NISAR and Sentinel-1 measure glacier velocity and sea-ice drift; combined with thickness, these give volume flux.'),
('Coverage limits','Orbital inclination limits what each mission observes: 66° N for the Jason series, 77.5° N for NISAR, 81.4° N for Sentinel-3 and 88° N for CryoSat-2 and ICESat-2.'),
('Snow','Snow depth remains the principal unknown for sea-ice thickness. Laser and radar errors act in opposite directions, and CRISTAL’s dual Ku- and Ka-band design is intended to address it.'),
('References','The extension references continue the main numbering from reference 26 onward.'),
]
def T(intro,terms,close=None):
    out=[(X,intro)]+list(terms)
    if close: out.append((X,close))
    return out
N['g1']=T('The following key-terms slides define the vocabulary of the course readings, beginning with the quantities from which every altimetric height is constructed.',[
('Range','The distance from the satellite to the surface, obtained from the two-way travel time as R = ct/2; it is the only quantity the altimeter measures directly (Magruder et al., 2024; Cheney, 2001).'),
('Orbit height and the ellipsoid','H is the satellite’s height above the reference ellipsoid, the smooth mathematical surface that serves as the height datum; it is determined from GNSS, DORIS and laser ranging to about 1 cm (Escudier et al., 2018).'),
('Geoid','The equipotential surface that a motionless ocean would follow under gravity alone, with undulations of about 200 m peak to peak. The sea surface follows it to within 1–2 %, so it must be removed before currents can be resolved (Cheney, 2001).'),
('Sea-surface height','SSH = H − R, the height of the sea surface above the ellipsoid.'),
('Mean sea surface and sea-level anomaly','The mean sea surface is SSH averaged over several years; the sea-level anomaly is the departure of SSH from that mean (Escudier et al., 2018).')],
'The subpolar-gyre trends reported by Chafik et al. (2019) are expressed as sea-level anomalies.')
N['g2']=T('These terms describe the corrections applied to the measured range; magnitudes are from Escudier et al. (2018).',[
('Dry troposphere','The delay due to atmospheric gases, about 2.3 m, computed from surface pressure in numerical weather models; it is the largest correction but also the most predictable.'),
('Wet troposphere','The delay due to water vapour and cloud liquid water, from millimetres at high latitudes to about 40 cm in the tropics, measured by an onboard microwave radiometer. Its spatial variability limits accuracy.'),
('Ionosphere','The delay due to free electrons, up to about 30 cm near solar maximum, removed by dual-frequency measurement; lasers are unaffected (Amani et al., 2022).'),
('Sea-state bias','Wave troughs reflect more radar energy than crests, so the measured mean surface lies too low by up to several centimetres or more; it is corrected empirically from wave height and wind speed.'),
('Precise orbit determination','Tracking of the satellite by GNSS, DORIS and laser ranging to about 1 cm radial accuracy, which makes a sea-level record at millimetre-per-year precision possible.')])
N['g3']=T('These terms describe the radar echo and the quantities derived from it.',[
('Waveform','Echo power as a function of time, recorded in 128 range gates of 0.47 m each in Ku band (Escudier et al., 2018).'),
('Leading edge and retracking','Retracking fits a model waveform, such as the Brown model, to the echo; the mid-point of the leading edge defines the range. Different surfaces require different retrackers.'),
('Speckle','Random fluctuation in individual echoes arising from the coherent sum of many facets with random phases. Thousands of echoes are averaged each second (Raney, 2014), about 1,000 per 1 Hz measurement (Fischer et al., 2024).'),
('Significant wave height','The mean height of the highest third of waves, derived from the rise time of the leading edge (Raney, 2014).'),
('Backscatter coefficient','σ⁰, the normalised echo strength, which decreases as wind roughens the sea surface and therefore yields wind speed (Raney, 2014; Cheney, 2001).')],
'Fischer et al. (2024) validated altimeter wave heights against Bering Sea buoys to within about 0.27 m.')
N['g4']=T('These terms concern footprints, the main distinction between radar and laser altimetry.',[
('Footprint','The area of the surface that contributes to the echo; it sets the smallest resolvable feature (Bufton, 1989).'),
('Pulse-limited footprint','A footprint defined by the pulse length rather than the antenna beam. For a radar altimeter it is about 2 km across over a calm sea and widens to about 10 km in high seas (Raney, 2014; Chelton et al., 1989).'),
('Beam-limited footprint','A footprint defined by the beam width. A laser beam is so narrow that its pulse-limited and beam-limited footprints coincide, giving spots of a few metres to tens of metres (Bufton, 1989).'),
('Delay-Doppler mode','Doppler processing that divides the radar footprint into along-track cells about 300 m long and approximately halves the height noise (Escudier et al., 2018; Raney, 2014).'),
('Full waveform and photon counting','GEDI records the complete return pulse, whereas ICESat-2 detects individual photons at 10,000 pulses per second (Magruder et al., 2024).')],
'The 300 m delay-Doppler cells are what allow CryoSat-2 and Sentinel-3 to detect individual leads in sea ice.')
N['g5']=T('These terms form the sea-ice vocabulary for freeboard and thickness; definitions follow Magruder et al. (2024).',[
('Lead','A linear opening of open water or thin new ice between floes, which provides the local sea-level reference.'),
('Floe','A discrete piece of floating sea ice, most of whose thickness, the draft, lies below the waterline.'),
('Freeboard','The height of the ice above local sea level. The laser measures to the snow surface, giving total freeboard; Ku-band radar measures mainly to the ice surface.'),
('Snow depth','The thickness of the snow layer on the ice, estimated from the difference between laser and radar freeboards or from dual-band radar (Kwok et al., 2020); it is the largest source of uncertainty in thickness.'),
('Marginal ice zone','The outer region of the pack, where waves break the ice into small floes. Sea ice attenuates waves and shelters the coast (Fischer et al., 2024).')],
'These are the quantities measured in the seas surrounding Greenland.')
N['g6']=T('These terms describe how ocean currents are inferred from sea-surface height.',[
('Dynamic topography','Sea-surface height minus the geoid, with highs and lows of about ±1 m (Cheney, 2001).'),
('Geostrophic current','Flow in which the horizontal pressure gradient associated with the sea-surface slope balances the Coriolis force, so that water moves along contours of constant height; in the Northern Hemisphere, higher sea level lies to the right of the flow.'),
('Gyre','A basin-scale circulation: anticyclonic, or clockwise, around a high and cyclonic around a low in the Northern Hemisphere.'),
('Western boundary current','The fast, narrow current on the western side of a gyre, such as the Gulf Stream, where sea-level variability reaches about 30 cm rms.'),
('Mesoscale eddy','A rotating feature 100 to 300 km across shed by meandering currents and tracked from week to week in altimeter maps.')],
'The North Atlantic contains both a subtropical and a subpolar gyre (Chafik et al., 2019).')
N['g7']=T('These terms describe the North Atlantic circulation that is central to my study; definitions and figures are from Chafik et al. (2019).',[
('Subpolar gyre','The cyclonic gyre south of Greenland, encompassing the Labrador and Irminger Seas. Its sea level rose by about 3.9 mm per year from the early 1990s and fell by about 7.1 mm per year from the mid-2000s.'),
('Gulf Stream and North Atlantic Current','The warm current system carrying heat north-eastward; its sea level varies in opposition to that of the subpolar gyre, forming a dipole.'),
('Atlantic Meridional Overturning Circulation','The circulation in which warm surface water flows north, sinks at high latitudes and returns south at depth; it weakened from the mid-2000s.'),
('Deep convection','The winter sinking of dense surface water, principally in the Labrador and Irminger Seas, which may drive shifts in the gyre.'),
('Steric and dynamic sea level','Steric change results from expansion or contraction of seawater with temperature and salinity; dynamic change results from circulation. Subpolar trends are dominated by steric changes driven by circulation.')])
N['g8']=T('These terms concern storms, winds and waves; definitions and figures are from Fischer et al. (2024), co-authored by Dr Farrell.',[
('Sea-ice extent','The area with at least 15 % ice concentration. In the Bering Sea, nine of the ten winters from 2014 to 2023 had anomalously low extent.'),
('Extratropical cyclone','A low-pressure system poleward of 30° latitude. Cyclone Merbok in September 2022 generated waves exceeding 15 m in the Bering Sea.'),
('Wave attenuation by sea ice','Sea ice damps wave energy and protects the coast; reduced ice cover allows more wave energy to reach the shore.'),
('Altimeter constellation','Several altimeters operating simultaneously. Five or more were required to sample every regional storm; with only two or three, short-lived storms were missed.'),
('Reanalysis and in-situ validation','ERA5 combines a numerical weather model with observations to produce a continuous record, and buoys validate altimeter wave heights to within about 0.27 m.')],
'The same methods could be applied to the seas surrounding Greenland.')
N['g9']=T('The final key-terms slide defines the ice-sheet vocabulary used to interpret elevation change; definitions and figures follow Magruder et al. (2024).',[
('Firn','Multi-year snow in the process of compacting into glacial ice. Radar penetrates it, and firn models are required to convert elevation change into mass change.'),
('Surface mass balance','Accumulation from snowfall minus losses from surface melt and runoff.'),
('Outlet glaciers and dynamic thinning','Fast-flowing glaciers that drain the ice sheet into the ocean and thin when they accelerate, for example in response to warmer ocean water.'),
('Elevation change rate','dh/dt, the rate of surface-height change from repeat altimetry; multiplied by density, it gives mass change.'),
('Sea-level contribution','Greenland and Antarctica together lost about 320 Gt per year over 2003–2019, equivalent to about 14 mm of global sea-level rise.')],
'Greenland’s outlet glaciers form part of my study region.')
