import re,sys
from bs4 import BeautifulSoup, NavigableString, Tag
src,dst,title_extra=sys.argv[1],sys.argv[2],sys.argv[3]
soup=BeautifulSoup(open(src).read(),'html.parser')
for sp in soup.select('span.mx[data-tex]'): sp.replace_with(NavigableString('$'+sp['data-tex']+'$'))
for iv in soup.select('i.v'):
    sb=iv.next_sibling
    v=iv.get_text()
    G={'σ':'\\sigma','η':'\\eta','ρ':'\\rho','λ':'\\lambda'};v=G.get(v,v)
    if isinstance(sb,Tag) and sb.name in ('sub','sup'):
        t=sb.get_text();sb.extract()
        iv.replace_with(NavigableString('$'+v+('_' if sb.name=='sub' else '^')+'{'+(t if sb.name=='sup' else '\\mathrm{'+t+'}')+'}$'))
    else: iv.replace_with(NavigableString('$'+v+'$'))
def txt(node):
    out=[]
    for c in node.descendants:
        if isinstance(c,NavigableString):
            if c.find_parent(['script','style','svg','math','aside']): continue
            out.append(str(c))
        elif isinstance(c,Tag):
            if c.name=='math' and not c.find_parent(['svg','aside']): out.append(' $'+c.get('alttext')+'$ ' if c.get('alttext') else ' '+' '.join(c.stripped_strings)+' ')
            elif c.name in ('span','b','div','br') and c.find_parent(class_=['stat','kicker']): out.append(' ')
    return re.sub(r'\s+',' ',''.join(out)).strip()
L=['# Radar & Laser Altimetry'+title_extra,'','**Shipu Debnath**  ','GEOG 789: Independent Study · Fall 2026  ','Submitted to **Dr. Sinéad L. Farrell**, Associate Professor  ','Department of Geographical Sciences, University of Maryland, College Park','',
'Text version of the HTML deck: slide text, speaker notes and references. Interactive figures, 3D views and animations are only in the HTML file.','']
secs=soup.select('main#stage > section.slide');G={'core':[],'ext':[],'gls':[]}
for s in secs: G['ext' if 'ext' in s['class'] else 'gls' if 'gls' in s['class'] else 'core'].append(s)
def emit(sec,label):
    h2=sec.find('h2');kick=sec.select_one('.kicker')
    title='Radar & Laser Altimetry' if sec['id']=='s1' else (txt(h2) if h2 else sec.get('data-title',''))
    L.append(f'## {label} — {title}')
    if kick:
        ks=[t for t in kick.stripped_strings];L.append('*'+' · '.join(ks)+'*')
    L.append('');seen=set()
    for el in sec.find_all(['h3','h4','p','li','span','div']):
        if el.find_parent(['aside','svg','script','style']) or el.find_parent(class_='foot') or el.find_parent('header') or el.find_parent(class_='refs'): continue
        cls=el.get('class') or []
        if el.name in ('span','div'):
            if not set(cls)&{'stat','fgl'}: continue
            if el.name=='div' and 'stat' in cls:
                parts=[x for x in (txt(c) for c in el.find_all(['b','span'],recursive=False)) if x]
                t=' — '.join(parts)
                if t and t not in seen: seen.add(t);L.append(t);L.append('')
                continue
        if el.find_parent(['p','li','h3','h4']) or el.find_parent(class_='stat'): continue
        t=txt(el)
        if not t or t in seen or len(t)<2: continue
        seen.add(t)
        L.append(f'**{t}**' if el.name in ('h3','h4') else f'- {t}' if el.name=='li' else t);L.append('')
    for tb in sec.find_all('table'):
        if tb.find_parent('aside'): continue
        rows=[[txt(c).replace('|','/') for c in tr.find_all(['td','th'])] for tr in tb.find_all('tr')];rows=[r for r in rows if any(r)]
        if not rows: continue
        n=max(len(r) for r in rows);rows=[r+['']*(n-len(r)) for r in rows]
        L.append('| '+' | '.join(rows[0])+' |');L.append('|'+'---|'*n);[L.append('| '+' | '.join(r)+' |') for r in rows[1:]];L.append('')
    eqs=[m.get('alttext') for m in sec.find_all('math') if m.get('alttext') and not m.find_parent(['aside','svg'])]
    if eqs:
        L.append('**Equations**');L.append('')
        for e in dict.fromkeys(eqs): L.append('$$'+e+'$$');L.append('')
    notes=sec.find('aside',class_='notes')
    if notes:
        L.append('> **Speaker notes**')
        for p in notes.find_all('p'): L.append('> ');L.append('> '+re.sub(r'\$ ([,.;:)])',r'$\1',re.sub(r'\s+',' ',' '.join(p.stripped_strings))))
        L.append('')
    L.append('---');L.append('')
L.append('# Part 1 — Core deck (slides 1–15)');L.append('')
for i,s in enumerate(G['core'],1): emit(s,f'Slide {i}')
if G['ext']:
    L.append('# Part 2 — Polar extension (slides 16–23)');L.append('')
    for i,s in enumerate(G['ext'],16): emit(s,f'Slide {i}')
if G['gls']:
    L.append(f'# Part 3 — Key terms (slides {16+len(G["ext"])}–{15+len(G["ext"])+len(G["gls"])}, T1–T9)');L.append('')
    for i,s in enumerate(G['gls'],1): emit(s,f'T{i}')
L.append('# References');L.append('')
for blk in soup.select('.refs'):
    if blk.find_parent('section') is None: continue
    for el in blk.find_all(['p','ol','h4']):
        if el.name=='h4' and 'Extension' in txt(el): L.append('## Extension references');L.append('');continue
        if el.name=='p' and 'refgrp' in (el.get('class') or []): L.append('## '+txt(el).capitalize());L.append('');continue
        if el.name=='ol':
            for li in el.find_all('li',recursive=False):
                n=li.get('id','').replace('ref-','');a=li.find('a')
                t=re.sub(r'\s*(doi|Google Scholar)?\s*↗\s*$','',txt(li)).strip()
                L.append(f'{n}. {t} <{a["href"]}>' if a and a.has_attr('href') else f'{n}. {t}')
            L.append('')
md=re.sub(r'\n{3,}','\n\n','\n'.join(L))
open(dst,'w').write(md);print(dst,len(md.split()),'words')
