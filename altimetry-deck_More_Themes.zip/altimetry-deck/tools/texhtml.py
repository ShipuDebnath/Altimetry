import html,re
G={'eta':'η','delta':'δ','Delta':'Δ','sigma':'σ','rho':'ρ','lambda':'λ','pi':'π','varphi':'φ','phi':'φ','nabla':'∇','partial':'∂','times':'×','cdot':'·','approx':'≈','int':'∫','mu':'μ'}
UP={'Delta','nabla','partial','times','cdot','approx','int','pi'}
def tok(s):
    i=0;out=[]
    while i<len(s):
        c=s[i]
        if c=='\\':
            m=re.match(r'\\([A-Za-z]+ ?|.)',s[i:]);out.append(('cmd',m.group(1).strip() or ' '));i+=len(m.group(0))
        elif c=='{':
            d=1;j=i+1
            while d:
                d+= {'{':1,'}':-1}.get(s[j],0);j+=1
            out.append(('grp',s[i+1:j-1]));i=j
        else: out.append(('ch',c));i+=1
    return out
def conv(s):
    t=tok(s);o=[];k=0
    def arg():
        nonlocal k
        if k<len(t):
            x=t[k];k+=1
            return conv(x[1]) if x[0]=='grp' else conv(('\\'+x[1]) if x[0]=='cmd' else x[1])
        return ''
    while k<len(t):
        ty,v=t[k];k+=1
        if ty=='cmd':
            if v in ('mathrm','text'):
                x=t[k];k+=1;o.append(html.escape(x[1]))
            elif v=='mathbf':
                x=t[k];k+=1;o.append('<b>'+html.escape(x[1])+'</b>')
            elif v=='sqrt': o.append('<span class="rt">√</span>('+arg()+')')
            elif v=='hat':
                x=t[k];k+=1;o.append('<b>'+html.escape(x[1])+'̂</b>')
            elif v==',': o.append(' ')
            elif v in ('times','approx'): o.append(' '+G[v]+' ')
            elif v in G: o.append(G[v] if v in UP else f'<i class="v">{G[v]}</i>')
            else: o.append(html.escape(v))
        elif ty=='grp': o.append(conv(v))
        else:
            if v==' ': continue
            if v in '=+-' :
                prev=''.join(o).rstrip()
                if v=='-' and (not prev or prev[-1] in '([=−+×'): o.append('−')
                else: o.append(' '+{'-':'−'}.get(v,v)+' ')
                continue
            if v=='_': o.append('<sub>'+arg()+'</sub>')
            elif v=='^': o.append('<sup>'+arg()+'</sup>')
            elif v=='-': o.append('−')
            elif re.match(r'[A-Za-z]',v): o.append(f'<i class="v">{v}</i>')
            else: o.append(html.escape(v))
    return ''.join(o)
def render(text):
    parts=re.split(r'\$(.+?)\$',text);out=[]
    for i,p in enumerate(parts):
        if i%2: out.append(f'<span class="mx" data-tex="{html.escape(p)}">{conv(p)}</span>')
        else: out.append(html.escape(p,quote=False))
    return ''.join(out)
