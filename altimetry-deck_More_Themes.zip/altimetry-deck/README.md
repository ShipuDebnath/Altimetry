# Radar & Laser Altimetry

An interactive HTML presentation on satellite radar and laser altimetry.

**Shipu Debnath** · GEOG 789: Independent Study · Fall 2026
Submitted to **Dr. Sinéad L. Farrell**, Associate Professor, Department of Geographical Sciences, University of Maryland, College Park

## Open the deck

Each HTML file is self-contained: open it in a browser, no build step or server needed.

| File | Contents |
|---|---|
| `index.html` | Full deck with all theme groups (core slides; polar and key-terms sections can be switched on in the toolbar) |
| `versions/extended/altimetry-deck-extended.html` | All 32 slides, polar and key-terms sections on |
| `versions/core/altimetry-deck-core.html` | First 15 slides only |
| `versions/*/…md` | Markdown text of each version, with speaker notes and equations in LaTeX |
| `src/altimetry-deck-classic.html` | Source deck with the original seven themes only |

To publish on GitHub Pages: *Settings → Pages → Deploy from branch → main / root*. `index.html` becomes the site.

## Controls

Arrow keys or space to move, `N` speaker notes, `/` search, `M` comment, `C` toolbar, `F` full screen, `T` next theme.
The toolbar swatch opens the theme menu.

## Themes

| Group | Themes |
|---|---|
| Classic | Glacier, Snow, Sea ice, Ocean mist, Aurora, Polar dawn, Firn |
| Glass | Frosted glass, Liquid glass, Borealis, Bioluminescent sea, Ice crystal, Prism, Midnight-sun glass |
| Motion | Champagne silk, Lava glass, Cartographer, Constellation, Under-ice light, Sonar field |
| Palette | Ember & basalt, Royal ink, Forest lab, Coral reef, Graphite & signal, Okabe–Ito (colour-blind safe) |

Each added group is self-contained in the built HTML and can be removed on its own:
a `<style id="themes-…">` block, a `<script id="fx-…">` block and a `<span class="sgrp" data-group="…">` row in the theme menu
(`glass`, `motion`, `palette`). Motion is reduced for viewers who have reduced motion enabled.

## Rebuild

Requires Python 3 (BeautifulSoup only for the Markdown export).

```bash
# themed deck from the classic source
python3 tools/make_themes.py src/altimetry-deck-classic.html index.html
# extended and core versions
python3 tools/release.py index.html versions altimetry-deck:themes
# Markdown exports
python3 tools/tomd.py versions/extended/altimetry-deck-extended.html versions/extended/altimetry-deck-extended.md " · Extended version"
python3 tools/tomd.py versions/core/altimetry-deck-core.html versions/core/altimetry-deck-core.md " · Core version (slides 1–15)"
```

`tools/generators/` holds the scripts that produced the key-terms slides and the speaker notes; `tools/texhtml.py` typesets the equations in the notes.

## References

References [1]–[10] are the course readings; [11]–[25] are additional sources; the polar extension continues from [26]. Full citations are on slide 15 and in the Markdown files.
